"""Source adapter base classes + a compliant HTTP helper.

All network access in sourcing goes through `polite_get`, which enforces the compliance
gate (ToS denylist, robots.txt, per-domain rate limiting) before issuing a request.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Optional
from urllib.parse import urljoin

import requests

from ..compliance import ComplianceGate, FetchDecision


@dataclass
class RawJob:
    """A job posting as scraped from a source, before dedup/persistence."""
    title: str
    url: str
    company_name: str
    location: Optional[str] = None
    salary_text: Optional[str] = None
    source: str = ""
    description: Optional[str] = None
    notify_only: bool = False  # True => ToS-forbidden; store link, open manually


@dataclass
class FetchResult:
    """Outcome of running one source."""
    jobs: list[RawJob] = field(default_factory=list)
    notify_only_links: list[str] = field(default_factory=list)
    error: Optional[str] = None


def polite_get(gate: ComplianceGate, url: str) -> tuple[Optional[str], FetchDecision]:
    """Fetch a URL through the compliance gate. Returns (html_or_None, decision).

    If the decision is notify_only or disallowed, no request is made and html is None.
    """
    decision = gate.check(url)
    if not decision.allowed:
        return None, decision
    gate.wait_for_rate_limit(url)
    resp = requests.get(
        url,
        headers={"User-Agent": gate.user_agent},
        timeout=gate.timeout,
    )
    resp.raise_for_status()
    return resp.text, decision


class Source(ABC):
    """Base class for a configured job source."""

    def __init__(self, config: dict, gate: ComplianceGate):
        self.config = config
        self.gate = gate
        self.name = config.get("name", config.get("url", "source"))

    @abstractmethod
    def fetch(self) -> FetchResult:
        """Return jobs (and any notify-only links) from this source."""

    @staticmethod
    def absolutize(base: str, href: str) -> str:
        return urljoin(base, href)


def build_source(config: dict, gate: ComplianceGate) -> Source:
    """Factory: construct the right adapter for a source config dict."""
    from .career_page import CareerPageSource
    from .rss import RssSource

    kind = (config.get("type") or "").lower()
    if kind == "rss":
        return RssSource(config, gate)
    if kind in ("career_page", "sponsor_board"):
        return CareerPageSource(config, gate)
    raise ValueError(f"Unknown source type: {config.get('type')!r} (use 'rss' or 'career_page')")
