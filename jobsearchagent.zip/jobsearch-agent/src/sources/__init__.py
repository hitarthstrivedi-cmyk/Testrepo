"""Pluggable, compliant job sources.

Every adapter fetches openings ONLY from sources that permit it (own career pages,
official RSS/APIs, visa-sponsorship boards). The ToS denylist (LinkedIn, Indeed, ...) is
enforced by the compliance gate before any request — those become notify-only links.

Add a source by appending an entry to `sources.enabled` in config.yaml; no code change
needed for the built-in `rss` and `career_page` types.
"""

from __future__ import annotations

from .base import RawJob, Source, build_source
from .career_page import CareerPageSource
from .rss import RssSource

__all__ = ["RawJob", "Source", "build_source", "CareerPageSource", "RssSource"]
