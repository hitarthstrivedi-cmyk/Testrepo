"""Generic HTML career-page adapter.

Config keys:
  name      (str)  display name
  type      "career_page" | "sponsor_board"
  url       (str)  the listing page
  company   (str, optional)  company name (defaults to name)
  enabled   (bool)
  selectors (dict):
    item     CSS selector for each job row/card (required)
    title    CSS selector for the title text within an item (optional; falls back to item text)
    link     CSS selector for the <a> within an item (optional; falls back to first <a>)
    location CSS selector for location text (optional)

Respects the compliance gate. If the page's domain is on the ToS denylist, it is recorded
as a notify-only link instead of being fetched.
"""

from __future__ import annotations

from .base import FetchResult, RawJob, Source, polite_get


class CareerPageSource(Source):
    def fetch(self) -> FetchResult:
        from bs4 import BeautifulSoup  # lazy: optional dependency

        url = self.config["url"]
        result = FetchResult()
        selectors = self.config.get("selectors", {})
        item_sel = selectors.get("item")
        if not item_sel:
            result.error = "career_page source requires selectors.item"
            return result

        text, decision = polite_get(self.gate, url)
        if text is None:
            if decision.notify_only:
                result.notify_only_links.append(url)
            else:
                result.error = decision.reason
            return result

        soup = BeautifulSoup(text, "lxml")
        company = self.config.get("company", self.name)

        for item in soup.select(item_sel):
            title_el = item.select_one(selectors["title"]) if selectors.get("title") else item
            title = (title_el.get_text(strip=True) if title_el else "").strip()

            link_el = item.select_one(selectors["link"]) if selectors.get("link") else item.find("a")
            href = link_el.get("href") if link_el and link_el.has_attr("href") else None
            if not title or not href:
                continue

            location = None
            if selectors.get("location"):
                loc_el = item.select_one(selectors["location"])
                location = loc_el.get_text(strip=True) if loc_el else None

            result.jobs.append(RawJob(
                title=title,
                url=self.absolutize(url, href),
                company_name=company,
                location=location,
                source=self.name,
            ))
        return result
