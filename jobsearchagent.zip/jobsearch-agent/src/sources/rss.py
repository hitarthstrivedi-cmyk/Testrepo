"""RSS/Atom job-feed adapter.

Config keys:
  name      (str)  display name
  type      "rss"
  url       (str)  the feed URL
  company   (str, optional)  default company name if the feed doesn't carry one
  enabled   (bool)

Feeds are a first-class compliant source: they are published explicitly for syndication.
The compliance gate still applies (denylist + robots.txt + rate limit).
"""

from __future__ import annotations

from .base import FetchResult, RawJob, Source, polite_get


class RssSource(Source):
    def fetch(self) -> FetchResult:
        import feedparser  # lazy: optional dependency

        url = self.config["url"]
        result = FetchResult()

        text, decision = polite_get(self.gate, url)
        if text is None:
            if decision.notify_only:
                result.notify_only_links.append(url)
            else:
                result.error = decision.reason
            return result

        parsed = feedparser.parse(text)
        default_company = self.config.get("company", self.name)
        for entry in parsed.entries:
            title = getattr(entry, "title", "").strip()
            link = getattr(entry, "link", "").strip()
            if not title or not link:
                continue
            result.jobs.append(RawJob(
                title=title,
                url=link,
                company_name=getattr(entry, "author", "") or default_company,
                location=getattr(entry, "location", None),
                source=self.name,
                description=getattr(entry, "summary", None),
            ))
        return result
