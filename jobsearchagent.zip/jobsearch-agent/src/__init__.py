"""Personal, local Netherlands HSM job-search agent."""

__version__ = "0.1.0"
