"""Sourcing orchestrator: run sources, dedup, detect new/reposts, notify.

Pipeline per scheduled run:
  1. For each enabled source, fetch postings through the compliance gate.
  2. ToS-denylisted domains yield notify-only links (stored as info notifications).
  3. Keep postings plausibly relevant to the configured roles/keywords.
  4. Dedup by URL; compute a role+company content hash for repost detection.
  5. Cross-reference the company against the IND recognised-sponsor register.
  6. Insert NEW jobs; flag REPOSTS (same role/company reappearing at a new URL).
  7. Dispatch notifications (dashboard always; email if configured).
  8. Record the run in `sourcing_runs`.

This module never submits anything — it only discovers and stores jobs.
"""

from __future__ import annotations

import datetime as _dt
import re

from . import ind_register, settings
from .compliance import ComplianceGate
from .db import connect
from .notify import Notification, dispatch
from .sources import build_source
from .sources.base import RawJob
from .text_util import content_hash, normalize_company


def _target_tokens() -> set[str]:
    cfg = settings.load_config().get("search", {})
    blob = " ".join(cfg.get("target_roles", []) + cfg.get("keywords", []))
    return {w for w in re.findall(r"[a-z]+", blob.lower()) if len(w) > 2}


def _is_relevant(job: RawJob, tokens: set[str]) -> bool:
    haystack = f"{job.title} {job.description or ''}".lower()
    hay_tokens = set(re.findall(r"[a-z]+", haystack))
    return bool(tokens & hay_tokens)


def _find_company_id(conn, company_name: str) -> int | None:
    norm = normalize_company(company_name)
    if not norm:
        return None
    row = conn.execute("SELECT id FROM companies WHERE normalized_name = ? LIMIT 1", (norm,)).fetchone()
    return row["id"] if row else None


def _persist_job(conn, job: RawJob, now: str) -> tuple[str, int] | None:
    """Insert or update a job. Returns ('new'|'repost'|'seen', job_id) or None if skipped."""
    chash = content_hash(job.company_name, job.title)
    sponsor = ind_register.is_recognised_sponsor(job.company_name)
    company_id = _find_company_id(conn, job.company_name)

    existing = conn.execute("SELECT id, times_seen FROM jobs WHERE url = ?", (job.url,)).fetchone()
    if existing:
        conn.execute(
            "UPDATE jobs SET last_seen = ?, times_seen = times_seen + 1 WHERE id = ?",
            (now, existing["id"]),
        )
        return ("seen", existing["id"])

    # New URL — is the same role/company already known elsewhere? => repost.
    prior = conn.execute("SELECT id FROM jobs WHERE content_hash = ? LIMIT 1", (chash,)).fetchone()
    is_repost = 1 if prior else 0

    cur = conn.execute(
        """INSERT INTO jobs
           (company_id, company_name, title, url, location, salary_text, description, source,
            is_recognised_sponsor, notify_only, content_hash, is_repost, first_seen, last_seen)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 0, ?, ?, ?, ?)""",
        (company_id, job.company_name, job.title, job.url, job.location, job.salary_text,
         job.description, job.source, 1 if sponsor else 0, chash, is_repost, now, now),
    )
    return ("repost" if is_repost else "new", cur.lastrowid)


def run_sourcing() -> dict[str, int]:
    """Run all enabled sources once. Returns a summary dict."""
    cfg = settings.load_config()
    sources_cfg = [s for s in cfg.get("sources", {}).get("enabled", []) if s.get("enabled", True)]
    gate = ComplianceGate(cfg)
    tokens = _target_tokens()
    now = _dt.datetime.utcnow().isoformat(timespec="seconds")

    notifications: list[Notification] = []
    summary = {"sources": 0, "fetched": 0, "kept": 0, "new": 0, "repost": 0, "notify_only": 0, "errors": 0}
    errors: list[str] = []

    with connect() as conn:
        run = conn.execute("INSERT INTO sourcing_runs (started_at) VALUES (?)", (now,))
        run_id = run.lastrowid

        for sconf in sources_cfg:
            summary["sources"] += 1
            try:
                source = build_source(sconf, gate)
                result = source.fetch()
            except Exception as exc:
                summary["errors"] += 1
                errors.append(f"{sconf.get('name', sconf.get('url'))}: {exc}")
                continue

            if result.error:
                summary["errors"] += 1
                errors.append(f"{source.name}: {result.error}")

            for link in result.notify_only_links:
                summary["notify_only"] += 1
                notifications.append(Notification(
                    type="info",
                    title=f"Manual check needed: {source.name}",
                    body=f"This source's Terms of Service forbid automated access. "
                         f"Open it yourself: {link}",
                ))

            for job in result.jobs:
                summary["fetched"] += 1
                if not _is_relevant(job, tokens):
                    continue
                summary["kept"] += 1
                outcome = _persist_job(conn, job, now)
                if not outcome:
                    continue
                kind, job_id = outcome
                if kind in ("new", "repost"):
                    summary[kind] += 1
                    notify_on = cfg.get("notifications", {}).get("notify_on", ["new", "repost"])
                    if kind in notify_on:
                        sponsor_tag = " [recognised sponsor]" if _job_is_sponsor(conn, job_id) else ""
                        notifications.append(Notification(
                            type=kind,
                            title=f"{'New' if kind == 'new' else 'Repost'}: {job.title} — {job.company_name}{sponsor_tag}",
                            body=f"{job.location or ''} · {job.url} (via {job.source})".strip(" ·"),
                            job_id=job_id,
                        ))

        conn.execute(
            "UPDATE sourcing_runs SET finished_at = ?, sources_run = ?, jobs_new = ?, jobs_repost = ?, errors = ? "
            "WHERE id = ?",
            (_dt.datetime.utcnow().isoformat(timespec="seconds"), summary["sources"],
             summary["new"], summary["repost"], "; ".join(errors) or None, run_id),
        )

    dispatch(notifications)
    return summary


def _job_is_sponsor(conn, job_id: int) -> bool:
    row = conn.execute("SELECT is_recognised_sponsor FROM jobs WHERE id = ?", (job_id,)).fetchone()
    return bool(row and row["is_recognised_sponsor"])


if __name__ == "__main__":
    print(f"Sourcing run summary: {run_sourcing()}")
