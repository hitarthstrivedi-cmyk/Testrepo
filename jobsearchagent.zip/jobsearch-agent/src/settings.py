"""Load configuration (config/config.yaml) and secrets (.env).

Everything in the project reads its settings through here so there is a single,
predictable source of truth. Secrets are pulled from the environment only.
"""

from __future__ import annotations

import os
from functools import lru_cache
from pathlib import Path
from typing import Any

import yaml
from dotenv import load_dotenv

# Project root = the jobsearch-agent/ directory (parent of src/).
PROJECT_ROOT = Path(__file__).resolve().parent.parent
CONFIG_PATH = PROJECT_ROOT / "config" / "config.yaml"

# Load .env once, from the project root, without overriding real env vars.
load_dotenv(PROJECT_ROOT / ".env", override=False)


@lru_cache(maxsize=1)
def load_config() -> dict[str, Any]:
    """Parse config/config.yaml into a dict (cached)."""
    if not CONFIG_PATH.exists():
        raise FileNotFoundError(f"Config not found: {CONFIG_PATH}")
    with CONFIG_PATH.open("r", encoding="utf-8") as fh:
        return yaml.safe_load(fh) or {}


def resolve_path(relative: str) -> Path:
    """Resolve a config path (relative to project root) to an absolute Path."""
    p = Path(relative)
    return p if p.is_absolute() else (PROJECT_ROOT / p)


def db_path() -> Path:
    cfg = load_config()
    return resolve_path(cfg.get("paths", {}).get("database", "data/jobsearch.db"))


def hsm_threshold() -> int:
    """Monthly gross HSM threshold (EUR, ex. 8% holiday allowance) for the configured bracket."""
    cfg = load_config()
    sal = cfg.get("salary", {})
    bracket = sal.get("hsm_bracket", "30plus")
    return int(sal["hsm_thresholds_2026"][bracket])


def minimum_salary() -> int:
    cfg = load_config()
    return int(cfg.get("salary", {}).get("minimum", hsm_threshold()))


# --- Secrets (env only) -------------------------------------------------------

def anthropic_api_key() -> str | None:
    return os.getenv("ANTHROPIC_API_KEY") or None


def anthropic_model() -> str:
    cfg = load_config()
    return os.getenv("ANTHROPIC_MODEL") or cfg.get("ai", {}).get("model", "claude-opus-4-8")


def smtp_config() -> dict[str, str | int | None]:
    return {
        "host": os.getenv("SMTP_HOST") or None,
        "port": int(os.getenv("SMTP_PORT", "587")),
        "user": os.getenv("SMTP_USER") or None,
        "password": os.getenv("SMTP_PASSWORD") or None,
        "from_addr": os.getenv("SMTP_FROM") or None,
        "to_addr": os.getenv("SMTP_TO") or None,
    }
