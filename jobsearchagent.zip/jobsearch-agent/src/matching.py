"""Phase 3 — matching + scoring.

For each job, compute a 0–100 profile-match score (JD vs. your master profile) with a
short strengths/gaps rationale, and flag whether the listed/expected salary meets the
2026 IND HSM threshold.

IMPORTANT: the score is a RELEVANCE HEURISTIC — how well the role aligns with your
profile — NOT a probability of being shortlisted. It is surfaced as such everywhere.

The salary-threshold flag is computed deterministically from the listed salary (not by the
model). Scoring uses the Claude API when ANTHROPIC_API_KEY is set (Opus 4.8, adaptive
thinking, prompt-cached profile, structured output), otherwise a deterministic offline
keyword-overlap heuristic.
"""

from __future__ import annotations

import argparse
import re
from dataclasses import dataclass, field

from . import settings
from .db import connect, init_db
from .profile import profile_as_text

# Tokens too generic to signal a real skill match.
_STOPWORDS = {
    "the", "and", "for", "with", "you", "your", "our", "are", "will", "have", "has",
    "this", "that", "from", "all", "who", "can", "job", "role", "work", "team", "we",
    "a", "an", "to", "of", "in", "on", "as", "is", "be", "at", "or", "by", "it",
    "experience", "experienced", "looking", "seek", "seeking", "join", "ability",
    "strong", "required", "requirements", "responsibilities", "about", "position",
}


@dataclass
class Score:
    score: int                       # 0..100 relevance heuristic
    rationale: str
    strengths: list[str] = field(default_factory=list)
    gaps: list[str] = field(default_factory=list)
    salary_meets_threshold: bool | None = None
    model: str = "offline"


# --- Salary parsing -----------------------------------------------------------

_AMOUNT_RE = re.compile(r"(?:€|eur|euro)?\s*([\d][\d.,\s]{2,})", re.IGNORECASE)
_YEARLY = re.compile(r"\b(per\s+year|year|yearly|annu|jaar|p\.?a\.?)\b", re.IGNORECASE)
_MONTHLY = re.compile(r"\b(per\s+month|month|monthly|maand|mo\b|p\.?m\.?)\b", re.IGNORECASE)


def _to_number(raw: str) -> float | None:
    """Parse a money string handling EU (1.234,56) and US (1,234.56) separators.

    A lone separator followed by exactly 3 digits is treated as a thousands separator
    (so '5.500' -> 5500 and '60.000' -> 60000), otherwise as a decimal point.
    """
    s = raw.strip().replace(" ", "")
    if not s:
        return None
    has_comma, has_dot = "," in s, "." in s
    if has_comma and has_dot:
        if s.rfind(",") > s.rfind("."):       # EU: 1.234,56 (comma = decimal)
            s = s.replace(".", "").replace(",", ".")
        else:                                  # US: 1,234.56 (dot = decimal)
            s = s.replace(",", "")
    elif has_comma:
        s = s.replace(",", "") if re.search(r",\d{3}$", s) else s.replace(",", ".")
    elif has_dot:
        s = s.replace(".", "") if re.search(r"\.\d{3}$", s) else s
    try:
        return float(s)
    except ValueError:
        return None


def _detect_currency(text: str) -> str:
    t = text.lower()
    if "$" in text or "usd" in t:
        return "USD"
    if "£" in text or "gbp" in t:
        return "GBP"
    return "EUR"


def parse_salary(text: str | None) -> dict | None:
    """Extract {min_monthly, max_monthly, currency, period} from a salary string, or None."""
    if not text:
        return None
    amounts = [n for n in (_to_number(m.group(1)) for m in _AMOUNT_RE.finditer(text)) if n and n >= 100]
    if not amounts:
        return None

    if _MONTHLY.search(text):
        period = "month"
    elif _YEARLY.search(text):
        period = "year"
    else:
        # Heuristic: large figures are annual, smaller ones monthly.
        period = "year" if max(amounts) > 15000 else "month"

    factor = 1 / 12 if period == "year" else 1.0
    monthly = sorted(a * factor for a in amounts)
    return {
        "min_monthly": round(monthly[0], 2),
        "max_monthly": round(monthly[-1], 2),
        "currency": _detect_currency(text),
        "period": period,
    }


def salary_meets_threshold(salary_text: str | None) -> tuple[bool | None, dict | None]:
    """Return (meets|None, parsed). None when no salary is listed or currency isn't EUR."""
    parsed = parse_salary(salary_text)
    if not parsed:
        return None, None
    if parsed["currency"] != "EUR":
        # The IND threshold is in EUR; don't compare a foreign-currency figure.
        return None, parsed
    # Give the benefit of the doubt: the top of the band must clear the threshold.
    return parsed["max_monthly"] >= settings.hsm_threshold(), parsed


# --- Job text -----------------------------------------------------------------

def _job_text(job: dict) -> str:
    parts = [job.get("title"), job.get("company_name"), job.get("location"), job.get("description")]
    return "\n".join(p for p in parts if p)


def _tokens(text: str) -> set[str]:
    return {w for w in re.findall(r"[a-zA-Z][a-zA-Z+#.]{2,}", text.lower()) if w not in _STOPWORDS}


# --- Offline scoring ----------------------------------------------------------

def _score_offline(job: dict) -> Score:
    profile_tokens = _tokens(profile_as_text())
    jd_tokens = _tokens(_job_text(job))
    if not jd_tokens:
        return Score(score=0, rationale="No job text available to score.", model="offline")

    overlap = jd_tokens & profile_tokens
    coverage = len(overlap) / len(jd_tokens)
    # Scale: full coverage is unrealistic, so map ~0.45 coverage -> ~90.
    score = max(0, min(100, round(coverage * 200)))

    strengths = sorted(overlap)[:8]
    gaps = sorted(jd_tokens - profile_tokens)[:8]
    rationale = (
        f"Relevance heuristic (offline): {len(overlap)} of {len(jd_tokens)} significant "
        f"job terms match your profile. NOT a shortlist probability."
    )
    return Score(score=score, rationale=rationale, strengths=strengths, gaps=gaps, model="offline")


# --- Claude scoring -----------------------------------------------------------

_SYSTEM = """\
You score how well a job fits a candidate's master profile, for the candidate's own triage.
Output a 0-100 RELEVANCE score: how aligned the role is with the candidate's background.
This is explicitly NOT a probability of being shortlisted — never imply it is.
Rules:
- Judge only on the master profile provided; do not invent candidate experience.
- strengths: concrete overlaps between the role and the profile (3-6 short phrases).
- gaps: requirements the profile does not clearly evidence (3-6 short phrases).
- rationale: 1-2 sentences, sober and specific. State it is a relevance heuristic.
- Do NOT consider salary or visa in the score; those are handled separately.
"""

_SCHEMA = {
    "type": "object",
    "properties": {
        "score": {"type": "integer"},
        "strengths": {"type": "array", "items": {"type": "string"}},
        "gaps": {"type": "array", "items": {"type": "string"}},
        "rationale": {"type": "string"},
    },
    "required": ["score", "strengths", "gaps", "rationale"],
    "additionalProperties": False,
}


def _score_claude(job: dict) -> Score:
    import anthropic

    client = anthropic.Anthropic()
    system = [
        {"type": "text", "text": _SYSTEM},
        {"type": "text", "text": f"CANDIDATE MASTER PROFILE:\n{profile_as_text()}",
         "cache_control": {"type": "ephemeral"}},
    ]
    user = (
        f"Score this job for relevance to the candidate.\n\n"
        f"Title: {job.get('title')}\nCompany: {job.get('company_name')}\n"
        f"Location: {job.get('location') or 'n/a'}\n\n"
        f"JOB DESCRIPTION:\n{job.get('description') or '(only the title is available)'}"
    )
    resp = client.messages.parse(
        model=settings.anthropic_model(),
        max_tokens=1500,
        thinking={"type": "adaptive"},
        system=system,
        messages=[{"role": "user", "content": user}],
        output_format=_SCHEMA,
    )
    d = resp.parsed_output
    score = max(0, min(100, int(d["score"])))
    return Score(
        score=score,
        rationale=d["rationale"].strip(),
        strengths=[s.strip() for s in d.get("strengths", []) if s.strip()],
        gaps=[g.strip() for g in d.get("gaps", []) if g.strip()],
        model=settings.anthropic_model(),
    )


# --- Public API ---------------------------------------------------------------

def score_job(job: dict) -> Score:
    """Score one job dict (must include title; company_name/location/description optional)."""
    if settings.anthropic_api_key():
        try:
            result = _score_claude(job)
        except Exception as exc:
            print(f"[matching] Claude path failed ({exc}); using offline.")
            result = _score_offline(job)
    else:
        result = _score_offline(job)

    meets, _ = salary_meets_threshold(job.get("salary_text"))
    result.salary_meets_threshold = meets
    return result


def _persist_score(conn, job_id: int, score: Score, parsed_salary: dict | None) -> None:
    conn.execute(
        """INSERT INTO match_scores (job_id, score, rationale, strengths, gaps,
               salary_meets_threshold, model, scored_at)
           VALUES (?, ?, ?, ?, ?, ?, ?, datetime('now'))
           ON CONFLICT(job_id) DO UPDATE SET
               score=excluded.score, rationale=excluded.rationale, strengths=excluded.strengths,
               gaps=excluded.gaps, salary_meets_threshold=excluded.salary_meets_threshold,
               model=excluded.model, scored_at=excluded.scored_at""",
        (job_id, score.score, score.rationale, "; ".join(score.strengths),
         "; ".join(score.gaps),
         None if score.salary_meets_threshold is None else int(score.salary_meets_threshold),
         score.model),
    )
    if parsed_salary:
        conn.execute(
            "UPDATE jobs SET salary_min=?, salary_max=?, salary_currency=?, salary_period=? WHERE id=?",
            (parsed_salary["min_monthly"], parsed_salary["max_monthly"],
             parsed_salary["currency"], parsed_salary["period"], job_id),
        )


def score_all(rescore: bool = False) -> dict[str, int]:
    """Score jobs. By default only unscored jobs; pass rescore=True to redo all."""
    init_db()
    summary = {"scored": 0, "meets_threshold": 0, "unknown_salary": 0}
    with connect() as conn:
        if rescore:
            jobs = conn.execute("SELECT * FROM jobs WHERE notify_only = 0").fetchall()
        else:
            jobs = conn.execute(
                "SELECT j.* FROM jobs j LEFT JOIN match_scores m ON m.job_id = j.id "
                "WHERE j.notify_only = 0 AND m.id IS NULL"
            ).fetchall()

        for row in jobs:
            job = dict(row)
            result = score_job(job)
            _, parsed = salary_meets_threshold(job.get("salary_text"))
            _persist_score(conn, job["id"], result, parsed)
            summary["scored"] += 1
            if result.salary_meets_threshold is True:
                summary["meets_threshold"] += 1
            elif result.salary_meets_threshold is None:
                summary["unknown_salary"] += 1
    return summary


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Score jobs for profile relevance + HSM salary flag.")
    parser.add_argument("--rescore", action="store_true", help="Re-score all jobs (not just unscored).")
    args = parser.parse_args()
    print(f"Scoring summary: {score_all(rescore=args.rescore)}")
