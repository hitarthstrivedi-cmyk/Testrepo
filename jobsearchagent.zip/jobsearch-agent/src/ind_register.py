"""IND public register of recognised sponsors (labour + highly skilled migrants).

The register is published by IND as a downloadable file (PDF), refreshed monthly. This
module downloads it, parses out company names, and upserts them into the `companies`
table with `is_recognised_sponsor = 1`. Each download is snapshotted for diffing.

Because the exact published format can change and the environment may not have outbound
access, parsing is defensive and you can also ingest a manually downloaded file:

    python -m src.ind_register --file ~/Downloads/Public_register_Regular_labour_and_HSM.pdf

Refresh cadence is monthly (configured in config.yaml). Re-running is idempotent: it
updates `last_seen` for companies still present.
"""

from __future__ import annotations

import argparse
import datetime as _dt
import re
from pathlib import Path

import requests

from . import settings
from .db import connect
from .text_util import normalize_company

# Lines that are page furniture, not company names.
_NOISE_RE = re.compile(
    r"^\s*(page\s+\d+|pagina\s+\d+|\d+\s*$|public register|openbaar register|"
    r"recognised sponsors|erkende referenten|organisation|organisatie|kvk|date|datum|"
    r"ind\b|www\.|https?://|©|labour|arbeid|highly skilled)",
    re.IGNORECASE,
)


def _register_dir() -> Path:
    d = settings.resolve_path(settings.load_config().get("paths", {}).get(
        "register_dir", "data/ind_register"))
    d.mkdir(parents=True, exist_ok=True)
    return d


def download_register(url: str | None = None) -> Path:
    """Download the register file to data/ind_register/<date>.<ext>. Returns the path.

    Note: the configured page URL is an HTML page that links to the actual file. If the
    URL points directly at a PDF, it's saved as-is; otherwise pass the file URL or use
    --file with a manually downloaded copy.
    """
    cfg = settings.load_config().get("ind_register", {})
    url = url or cfg.get("public_register_url")
    if not url:
        raise ValueError("No IND register URL configured.")

    compliance = settings.load_config().get("compliance", {})
    headers = {"User-Agent": compliance.get("user_agent", "personal-jobsearch-agent/0.1")}
    resp = requests.get(url, headers=headers,
                        timeout=compliance.get("request_timeout_seconds", 20))
    resp.raise_for_status()

    ext = "pdf" if "pdf" in resp.headers.get("content-type", "").lower() or url.lower().endswith(".pdf") else "html"
    dest = _register_dir() / f"register_{_dt.date.today().isoformat()}.{ext}"
    dest.write_bytes(resp.content)
    return dest


def parse_register(path: str | Path) -> list[str]:
    """Extract a list of company names from a register file (.pdf, .csv, .txt)."""
    p = Path(path)
    suffix = p.suffix.lower()
    if suffix == ".pdf":
        return _parse_pdf(p)
    if suffix in (".csv",):
        return _parse_csv(p)
    if suffix in (".txt",):
        return [ln.strip() for ln in p.read_text(encoding="utf-8", errors="ignore").splitlines()
                if ln.strip() and not _NOISE_RE.match(ln.strip())]
    raise ValueError(f"Unsupported register format: {suffix} (use .pdf, .csv, or .txt)")


def _parse_pdf(p: Path) -> list[str]:
    from pypdf import PdfReader

    reader = PdfReader(str(p))
    names: list[str] = []
    for page in reader.pages:
        for raw in (page.extract_text() or "").splitlines():
            line = raw.strip()
            if not line or len(line) < 2 or _NOISE_RE.match(line):
                continue
            # Drop trailing KVK numbers if present on the same line.
            line = re.sub(r"\s{2,}\d{6,}\s*$", "", line).strip()
            names.append(line)
    return names


def _parse_csv(p: Path) -> list[str]:
    import csv

    names: list[str] = []
    with p.open(newline="", encoding="utf-8", errors="ignore") as fh:
        reader = csv.reader(fh)
        rows = list(reader)
    if not rows:
        return names
    # Find the column most likely to hold the organisation name.
    header = [h.lower() for h in rows[0]]
    name_idx = next((i for i, h in enumerate(header)
                     if any(k in h for k in ("organis", "company", "naam", "name"))), 0)
    data_rows = rows[1:] if any(k in " ".join(header) for k in ("organis", "company", "naam", "name")) else rows
    for row in data_rows:
        if len(row) > name_idx and row[name_idx].strip():
            names.append(row[name_idx].strip())
    return names


def upsert_companies(names: list[str], file_path: Path | None = None) -> dict[str, int]:
    """Insert/update companies. Returns counts {added, updated, total}."""
    now = _dt.datetime.utcnow().isoformat(timespec="seconds")
    added = updated = 0
    seen: set[str] = set()

    with connect() as conn:
        for raw in names:
            norm = normalize_company(raw)
            if not norm or norm in seen:
                continue
            seen.add(norm)
            row = conn.execute(
                "SELECT id FROM companies WHERE normalized_name = ? AND kvk_number IS NULL",
                (norm,),
            ).fetchone()
            if row:
                conn.execute("UPDATE companies SET last_seen = ?, is_recognised_sponsor = 1 WHERE id = ?",
                             (now, row["id"]))
                updated += 1
            else:
                conn.execute(
                    "INSERT INTO companies (name, normalized_name, is_recognised_sponsor, first_seen, last_seen) "
                    "VALUES (?, ?, 1, ?, ?)",
                    (raw.strip(), norm, now, now),
                )
                added += 1

        if file_path is not None:
            conn.execute(
                "INSERT INTO register_snapshots (file_path, company_count) VALUES (?, ?)",
                (str(file_path), len(seen)),
            )

    return {"added": added, "updated": updated, "total": len(seen)}


def is_recognised_sponsor(company_name: str) -> bool:
    """True if a company (by normalized name) is in the recognised-sponsor register."""
    norm = normalize_company(company_name)
    if not norm:
        return False
    with connect() as conn:
        row = conn.execute(
            "SELECT 1 FROM companies WHERE normalized_name = ? AND is_recognised_sponsor = 1 LIMIT 1",
            (norm,),
        ).fetchone()
    return row is not None


def mark_relevant(keywords: list[str] | None = None) -> int:
    """Flag companies whose name plausibly matches the field (weak heuristic).

    Name-based relevance is intentionally loose — the authoritative relevance signal is a
    matching JOB at the company (Phase 3). This only produces a shortlist to eyeball.
    """
    cfg = settings.load_config().get("search", {})
    kws = keywords or (cfg.get("keywords", []) + cfg.get("target_roles", []))
    tokens = {w.lower() for kw in kws for w in re.findall(r"[a-z]+", kw.lower()) if len(w) > 3}
    # Generic industry hints that often indicate a relevant employer.
    tokens |= {"tech", "data", "digital", "software", "consult", "analytics", "ai",
               "bank", "insurance", "solutions", "systems", "intelligence"}

    flagged = 0
    with connect() as conn:
        for row in conn.execute("SELECT id, normalized_name FROM companies"):
            name_tokens = set(row["normalized_name"].split())
            relevant = 1 if (name_tokens & tokens) else 0
            conn.execute("UPDATE companies SET relevant = ? WHERE id = ?", (relevant, row["id"]))
            flagged += relevant
    return flagged


def refresh(url: str | None = None, file: str | None = None) -> dict[str, int]:
    """Download (or use a local file), parse, upsert, and flag relevance."""
    path = Path(file) if file else download_register(url)
    names = parse_register(path)
    if not names:
        raise RuntimeError(f"Parsed 0 companies from {path}; check the file format.")
    counts = upsert_companies(names, file_path=path)
    counts["relevant"] = mark_relevant()
    return counts


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Refresh the IND recognised-sponsor register.")
    parser.add_argument("--file", help="Path to a manually downloaded register (.pdf/.csv/.txt)")
    parser.add_argument("--url", help="Override the register download URL")
    args = parser.parse_args()

    result = refresh(url=args.url, file=args.file)
    print(f"Register refreshed: {result}")
