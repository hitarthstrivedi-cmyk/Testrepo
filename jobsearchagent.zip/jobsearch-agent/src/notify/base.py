"""Notification model + channel interface."""

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import Optional


@dataclass
class Notification:
    type: str            # "new" | "repost" | "info"
    title: str
    body: str = ""
    job_id: Optional[int] = None


class Channel(ABC):
    name: str = "channel"

    @abstractmethod
    def send(self, notifications: list[Notification]) -> None:
        """Deliver a batch of notifications."""
