"""Dispatch notifications to all channels enabled in config.yaml.

`dashboard` is always included (it's the dashboard's data source). `email` is added when
listed in notifications.channels AND SMTP is configured. New channels: implement Channel
and register them here.
"""

from __future__ import annotations

from .. import settings
from .base import Channel, Notification
from .dashboard import DashboardChannel
from .email import EmailChannel


def _active_channels() -> list[Channel]:
    configured = set(settings.load_config().get("notifications", {}).get("channels", []))
    channels: list[Channel] = [DashboardChannel()]  # always on
    if "email" in configured:
        channels.append(EmailChannel())
    return channels


def dispatch(notifications: list[Notification]) -> None:
    """Send notifications across all active channels."""
    if not notifications:
        return
    for channel in _active_channels():
        try:
            channel.send(notifications)
        except Exception as exc:  # one bad channel shouldn't sink the others
            print(f"[notify] channel '{channel.name}' failed: {exc}")
