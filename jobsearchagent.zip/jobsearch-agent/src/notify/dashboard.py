"""Dashboard channel: persist notifications to the `notifications` table.

This channel is always active — it's how the local dashboard (Phase 5) surfaces alerts.
"""

from __future__ import annotations

import datetime as _dt

from ..db import connect
from .base import Channel, Notification


class DashboardChannel(Channel):
    name = "dashboard"

    def send(self, notifications: list[Notification]) -> None:
        now = _dt.datetime.utcnow().isoformat(timespec="seconds")
        with connect() as conn:
            for n in notifications:
                conn.execute(
                    "INSERT INTO notifications (type, job_id, title, body, channel, created_at) "
                    "VALUES (?, ?, ?, ?, 'dashboard', ?)",
                    (n.type, n.job_id, n.title, n.body, now),
                )
