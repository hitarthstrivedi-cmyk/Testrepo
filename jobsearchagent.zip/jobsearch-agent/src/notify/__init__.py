"""Pluggable notification channels (dashboard table + email; add more here)."""

from __future__ import annotations

from .base import Notification
from .dispatch import dispatch

__all__ = ["Notification", "dispatch"]
