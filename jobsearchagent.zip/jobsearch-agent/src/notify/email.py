"""Email channel (SMTP). Active only when SMTP_* env vars are set in .env.

For Gmail, create an App Password (https://myaccount.google.com/apppasswords) and set
SMTP_HOST=smtp.gmail.com, SMTP_PORT=587, SMTP_USER/SMTP_PASSWORD, SMTP_FROM, SMTP_TO.
"""

from __future__ import annotations

import datetime as _dt
import smtplib
from email.message import EmailMessage

from .. import settings
from ..db import connect
from .base import Channel, Notification


class EmailChannel(Channel):
    name = "email"

    def __init__(self) -> None:
        self.cfg = settings.smtp_config()

    def is_configured(self) -> bool:
        c = self.cfg
        return bool(c["host"] and c["user"] and c["password"] and c["from_addr"])

    def send(self, notifications: list[Notification]) -> None:
        if not notifications:
            return
        if not self.is_configured():
            print("[notify.email] SMTP not configured (.env); skipping email channel.")
            return

        c = self.cfg
        to_addr = c["to_addr"] or settings.load_config().get("notifications", {}).get("email")
        if not to_addr:
            print("[notify.email] No recipient (SMTP_TO / notifications.email); skipping.")
            return

        lines = [f"- [{n.type.upper()}] {n.title}\n  {n.body}" for n in notifications]
        body = "New job-search matches:\n\n" + "\n\n".join(lines)

        msg = EmailMessage()
        msg["Subject"] = f"[job-search] {len(notifications)} new/reposted match(es)"
        msg["From"] = c["from_addr"]
        msg["To"] = to_addr
        msg.set_content(body)

        with smtplib.SMTP(c["host"], int(c["port"])) as server:
            server.starttls()
            server.login(c["user"], c["password"])
            server.send_message(msg)

        # Mark these as sent on the email channel for the audit trail.
        now = _dt.datetime.utcnow().isoformat(timespec="seconds")
        with connect() as conn:
            for n in notifications:
                if n.job_id is not None:
                    conn.execute(
                        "UPDATE notifications SET sent_at = ? WHERE job_id = ? AND channel = 'dashboard' AND sent_at IS NULL",
                        (now, n.job_id),
                    )
