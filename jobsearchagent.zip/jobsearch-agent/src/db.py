"""SQLite schema and connection helpers.

Run `python -m src.db` to create/upgrade the database (idempotent).

The schema is forward-compatible: tables for every phase are created now so later
phases only add logic, not migrations. Nothing here sends anything or touches the
network — it is pure local storage.
"""

from __future__ import annotations

import sqlite3
from contextlib import contextmanager
from pathlib import Path
from typing import Iterator

from .settings import db_path

# Application pipeline states (Phase 4/5). "Found" is the implicit default for jobs.
PIPELINE_STATES = [
    "Found",
    "Approved",
    "Applied",
    "Response",
    "Interview",
    "Offer",
    "Rejected",
]

SCHEMA = """
PRAGMA journal_mode = WAL;
PRAGMA foreign_keys = ON;

-- IND recognised-sponsor companies (Phase 2). One row per company in the register.
CREATE TABLE IF NOT EXISTS companies (
    id                   INTEGER PRIMARY KEY AUTOINCREMENT,
    name                 TEXT    NOT NULL,
    normalized_name      TEXT    NOT NULL,          -- lowercased/trimmed for matching & dedup
    kvk_number           TEXT,
    city                 TEXT,
    register_category    TEXT,                       -- e.g. "Regular labour and highly skilled migrants"
    is_recognised_sponsor INTEGER NOT NULL DEFAULT 1,
    relevant             INTEGER NOT NULL DEFAULT 0,  -- 1 if plausibly in the user's field
    first_seen           TEXT    NOT NULL DEFAULT (datetime('now')),
    last_seen            TEXT    NOT NULL DEFAULT (datetime('now')),
    UNIQUE(normalized_name, kvk_number)
);
CREATE INDEX IF NOT EXISTS idx_companies_norm ON companies(normalized_name);
CREATE INDEX IF NOT EXISTS idx_companies_relevant ON companies(relevant);

-- Job postings discovered via compliant sources (Phase 2).
CREATE TABLE IF NOT EXISTS jobs (
    id                   INTEGER PRIMARY KEY AUTOINCREMENT,
    company_id           INTEGER REFERENCES companies(id) ON DELETE SET NULL,
    company_name         TEXT    NOT NULL,
    title                TEXT    NOT NULL,
    url                  TEXT    NOT NULL UNIQUE,
    location             TEXT,
    salary_text          TEXT,                        -- raw, as listed
    salary_min           REAL,
    salary_max           REAL,
    salary_currency      TEXT,
    salary_period        TEXT,                        -- "month" | "year"
    description          TEXT,                        -- JD text (if the source provides it)
    source               TEXT    NOT NULL,            -- adapter/board name
    is_recognised_sponsor INTEGER NOT NULL DEFAULT 0,
    notify_only          INTEGER NOT NULL DEFAULT 0,  -- 1 = ToS-forbidden source; open manually
    content_hash         TEXT,                        -- for repost detection
    times_seen           INTEGER NOT NULL DEFAULT 1,
    is_repost            INTEGER NOT NULL DEFAULT 0,
    status               TEXT    NOT NULL DEFAULT 'Found',
    first_seen           TEXT    NOT NULL DEFAULT (datetime('now')),
    last_seen            TEXT    NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_jobs_company ON jobs(company_id);
CREATE INDEX IF NOT EXISTS idx_jobs_status ON jobs(status);
CREATE INDEX IF NOT EXISTS idx_jobs_hash ON jobs(content_hash);

-- Relevance scoring (Phase 3). One latest row per job (re-scored in place).
CREATE TABLE IF NOT EXISTS match_scores (
    id                     INTEGER PRIMARY KEY AUTOINCREMENT,
    job_id                 INTEGER NOT NULL REFERENCES jobs(id) ON DELETE CASCADE,
    score                  INTEGER NOT NULL,           -- 0..100 relevance heuristic (NOT a shortlist probability)
    rationale              TEXT,
    strengths              TEXT,
    gaps                   TEXT,
    salary_meets_threshold INTEGER,                    -- 1/0/NULL(unknown)
    model                  TEXT,
    scored_at              TEXT    NOT NULL DEFAULT (datetime('now')),
    UNIQUE(job_id)
);

-- HITL application workflow (Phase 4). Created only when the user approves a job.
CREATE TABLE IF NOT EXISTS applications (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    job_id       INTEGER NOT NULL REFERENCES jobs(id) ON DELETE CASCADE UNIQUE,
    method       TEXT    NOT NULL DEFAULT 'unknown',   -- "form" | "email" | "unknown"
    status       TEXT    NOT NULL DEFAULT 'Approved',
    package_path TEXT,                                  -- folder with tailored CV + cover letter
    hr_email     TEXT,                                  -- only if explicitly listed; never invented
    approved     INTEGER NOT NULL DEFAULT 0,            -- explicit HITL gate; must be 1 before any send
    approved_at  TEXT,
    applied_at   TEXT,
    notes        TEXT,
    created_at   TEXT    NOT NULL DEFAULT (datetime('now')),
    updated_at   TEXT    NOT NULL DEFAULT (datetime('now'))
);

-- Audit trail of pipeline transitions (Phase 5).
CREATE TABLE IF NOT EXISTS status_history (
    id             INTEGER PRIMARY KEY AUTOINCREMENT,
    application_id INTEGER NOT NULL REFERENCES applications(id) ON DELETE CASCADE,
    from_status    TEXT,
    to_status      TEXT    NOT NULL,
    note           TEXT,
    changed_at     TEXT    NOT NULL DEFAULT (datetime('now'))
);

-- Notifications (Phase 2/5). Pluggable channels; "dashboard" rows are always written.
CREATE TABLE IF NOT EXISTS notifications (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    type       TEXT    NOT NULL,                        -- "new" | "repost" | "info"
    job_id     INTEGER REFERENCES jobs(id) ON DELETE SET NULL,
    title      TEXT    NOT NULL,
    body       TEXT,
    channel    TEXT    NOT NULL DEFAULT 'dashboard',
    is_read    INTEGER NOT NULL DEFAULT 0,
    created_at TEXT    NOT NULL DEFAULT (datetime('now')),
    sent_at    TEXT
);
CREATE INDEX IF NOT EXISTS idx_notifications_read ON notifications(is_read);

-- Record of each scheduled sourcing run (Phase 2) for observability.
CREATE TABLE IF NOT EXISTS sourcing_runs (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    started_at   TEXT    NOT NULL DEFAULT (datetime('now')),
    finished_at  TEXT,
    sources_run  INTEGER NOT NULL DEFAULT 0,
    jobs_new     INTEGER NOT NULL DEFAULT 0,
    jobs_repost  INTEGER NOT NULL DEFAULT 0,
    errors       TEXT
);

-- Snapshots of the IND register downloads (Phase 2), for monthly-refresh diffing.
CREATE TABLE IF NOT EXISTS register_snapshots (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    downloaded_at TEXT    NOT NULL DEFAULT (datetime('now')),
    file_path     TEXT    NOT NULL,
    company_count INTEGER NOT NULL DEFAULT 0
);
"""


def get_connection(path: Path | None = None) -> sqlite3.Connection:
    """Open a SQLite connection with sensible defaults and Row access."""
    target = path or db_path()
    target.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(target)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON;")
    return conn


@contextmanager
def connect(path: Path | None = None) -> Iterator[sqlite3.Connection]:
    """Context-managed connection that commits on success and always closes."""
    conn = get_connection(path)
    try:
        yield conn
        conn.commit()
    finally:
        conn.close()


# Columns added after the initial schema shipped: (table, column, definition).
# Applied idempotently so existing databases upgrade without a manual migration.
_ADDED_COLUMNS = [
    ("jobs", "description", "TEXT"),
]


def _migrate(conn: sqlite3.Connection) -> None:
    for table, column, decl in _ADDED_COLUMNS:
        cols = {r["name"] for r in conn.execute(f"PRAGMA table_info({table})")}
        if column not in cols:
            conn.execute(f"ALTER TABLE {table} ADD COLUMN {column} {decl}")


def init_db(path: Path | None = None) -> Path:
    """Create the database and all tables (idempotent), then apply column migrations."""
    target = path or db_path()
    target.parent.mkdir(parents=True, exist_ok=True)
    with connect(target) as conn:
        conn.executescript(SCHEMA)
        _migrate(conn)
    return target


if __name__ == "__main__":
    created = init_db()
    print(f"Database ready: {created}")
