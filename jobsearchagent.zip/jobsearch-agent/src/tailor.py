"""Per-job tailoring: given a job description, produce a tailored CV + NL cover letter.

Primary path uses the Claude API (Opus 4.8) with:
  - the master profile cached as a stable system prefix (prompt caching), so each
    job only pays for the volatile job-description tokens;
  - adaptive thinking;
  - structured outputs (a validated Pydantic schema) for deterministic parsing.

If no ANTHROPIC_API_KEY is set (or `anthropic` isn't installed), it falls back to a
deterministic, offline tailoring: competencies are re-ordered by keyword overlap and
the cover letter is filled from templates/cover_letter.j2.

The cover letter positions the candidate as a LOW-FRICTION highly skilled migrant
hire: they meet the 2026 IND salary threshold and HSM criteria, so sponsorship via a
recognised sponsor is fast and low-risk. The EMPLOYER runs the IND process.

Nothing here sends an application — it only generates documents for the HITL workflow.
"""

from __future__ import annotations

import datetime as _dt
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from jinja2 import Environment, FileSystemLoader, select_autoescape

from . import settings
from .profile import load_master_profile, profile_as_text

MODEL_FALLBACK_NOTE = "(generated offline — no Claude API key set)"


@dataclass
class TailoredContent:
    """The tailored output for one job."""
    profile_summary: str
    competencies: list[str]
    cover_letter: str
    match_highlights: list[str] = field(default_factory=list)
    source: str = "claude"  # "claude" | "offline"


# --- HSM framing helper -------------------------------------------------------

def _hsm_framing() -> str:
    threshold = settings.hsm_threshold()
    cfg = settings.load_config()
    bracket = cfg.get("salary", {}).get("hsm_bracket", "30plus")
    age_clause = "aged 30 or over" if bracket == "30plus" else "under 30"
    return (
        f"The candidate qualifies under the Netherlands Highly Skilled Migrant "
        f"(kennismigrant) scheme and expects to meet the 2026 IND gross monthly salary "
        f"threshold of €{threshold:,} (for applicants {age_clause}, excluding the 8% "
        f"holiday allowance). Because the candidate clearly meets the threshold and HSM "
        f"criteria, sponsorship through a recognised sponsor is fast and low-risk: the "
        f"EMPLOYER (not the candidate) runs the straightforward IND process, and no "
        f"labour-market test applies."
    )


def _hsm_note_first_person() -> str:
    """First-person HSM paragraph for the offline cover-letter template."""
    threshold = settings.hsm_threshold()
    return (
        f"I qualify under the Netherlands Highly Skilled Migrant (kennismigrant) scheme and "
        f"meet the 2026 IND gross monthly salary threshold of €{threshold:,} (excluding the "
        f"8% holiday allowance). Sponsorship runs through your standard IND process as the "
        f"recognised sponsor, with no labour-market test, so onboarding is fast and predictable."
    )


# =============================================================================
# Primary path: Claude API
# =============================================================================

_SYSTEM_INSTRUCTIONS = """\
You are an expert career writer for the Netherlands job market. You tailor a candidate's
CV emphasis and write a Dutch/European-style cover letter for a specific job.

Hard rules:
- NEVER invent experience, employers, dates, metrics, or skills. Use ONLY what is in the
  candidate master profile. You may re-order, re-emphasise, and re-phrase honestly.
- The cover letter must be concise (Dutch style: ~250-320 words, 3-4 short paragraphs),
  professional, specific to the company/role, and free of clichés and flattery.
- Include exactly one short paragraph positioning the candidate as a low-friction Highly
  Skilled Migrant hire, using the provided HSM framing. Frame sponsorship as the
  EMPLOYER's straightforward process, not a burden the candidate imposes.
- Do NOT mention age, marital status, gender, nationality, or a photo anywhere.
- profile_summary: a tightened 3-4 line professional summary aligned to this job.
- competencies: 6-8 of the candidate's core competencies, ordered by relevance to the JD.
- match_highlights: 3-5 short bullet phrases naming concrete strengths for THIS role.
"""

_OUTPUT_SCHEMA = {
    "type": "object",
    "properties": {
        "profile_summary": {"type": "string"},
        "competencies": {"type": "array", "items": {"type": "string"}},
        "cover_letter": {"type": "string"},
        "match_highlights": {"type": "array", "items": {"type": "string"}},
    },
    "required": ["profile_summary", "competencies", "cover_letter", "match_highlights"],
    "additionalProperties": False,
}


def _tailor_with_claude(job_description: str, company: str, role: str) -> TailoredContent:
    import anthropic

    client = anthropic.Anthropic()  # reads ANTHROPIC_API_KEY from env
    profile_text = profile_as_text()

    # Stable, cacheable prefix: instructions + master profile + HSM framing.
    # Volatile job-specific content goes in the user message (after the breakpoint).
    system = [
        {"type": "text", "text": _SYSTEM_INSTRUCTIONS},
        {
            "type": "text",
            "text": (
                f"CANDIDATE MASTER PROFILE:\n{profile_text}\n\n"
                f"HSM FRAMING (use once, paraphrased):\n{_hsm_framing()}"
            ),
            "cache_control": {"type": "ephemeral"},
        },
    ]

    user = (
        f"Tailor for this job.\n\nCompany: {company}\nRole: {role}\n\n"
        f"JOB DESCRIPTION:\n{job_description.strip()}"
    )

    response = client.messages.parse(
        model=settings.anthropic_model(),
        max_tokens=4000,
        thinking={"type": "adaptive"},
        system=system,
        messages=[{"role": "user", "content": user}],
        output_format=_OUTPUT_SCHEMA,
    )

    data = response.parsed_output
    return TailoredContent(
        profile_summary=data["profile_summary"].strip(),
        competencies=[c.strip() for c in data["competencies"] if c.strip()],
        cover_letter=data["cover_letter"].strip(),
        match_highlights=[h.strip() for h in data.get("match_highlights", []) if h.strip()],
        source="claude",
    )


# =============================================================================
# Fallback path: deterministic, offline
# =============================================================================

_WORD_RE = re.compile(r"[a-z0-9+#.]+")


def _tokens(text: str) -> set[str]:
    return {w for w in _WORD_RE.findall(text.lower()) if len(w) > 2}


def _rank_competencies(competencies: list[str], jd_tokens: set[str]) -> list[str]:
    """Order competencies by token overlap with the JD (stable for ties)."""
    def score(c: str) -> int:
        return len(_tokens(c) & jd_tokens)
    return sorted(competencies, key=lambda c: (-score(c), competencies.index(c)))


def _tailor_offline(job_description: str, company: str, role: str) -> TailoredContent:
    profile = load_master_profile()
    jd_tokens = _tokens(job_description)

    competencies = _rank_competencies(list(profile.get("core_competencies", [])), jd_tokens)

    # Pick the strongest matching achievements as highlights.
    achievements = profile.get("achievements", [])
    highlights = sorted(
        achievements,
        key=lambda a: (-len(_tokens(a) & jd_tokens), achievements.index(a)),
    )[:3]

    env = Environment(
        loader=FileSystemLoader(str(settings.resolve_path(
            settings.load_config()["paths"]["templates_dir"]))),
        autoescape=select_autoescape([]),
        trim_blocks=True,
        lstrip_blocks=True,
    )
    template = env.get_template("cover_letter.j2")
    contact = profile.get("contact", {})
    current = profile.get("experience", [{}])[0]
    cover_letter = template.render(
        today=_dt.date.today().strftime("%d %B %Y"),
        greeting="Hiring Manager",
        role=role,
        company=company,
        opening_hook=f"Your {role} role is a strong fit for my background in "
                     f"{competencies[0].lower() if competencies else 'strategy and AI'}.",
        current_role=f"{current.get('role','my current role')} at {current.get('company','')}".strip(),
        key_value_sentence="lead enterprise AI adoption and turn business problems into "
                           "scalable analytics and automation use cases",
        supporting_sentence=(highlights[0] if highlights else ""),
        hsm_note=_hsm_note_first_person(),
        name=profile.get("name", ""),
        email=contact.get("email", ""),
        phone=contact.get("phone", ""),
    ).strip()

    return TailoredContent(
        profile_summary=profile.get("profile", "").strip(),
        competencies=competencies[:8],
        cover_letter=cover_letter,
        match_highlights=highlights,
        source="offline",
    )


# =============================================================================
# Public API
# =============================================================================

def tailor_for_job(job_description: str, company: str, role: str) -> TailoredContent:
    """Produce tailored CV emphasis + cover letter. Uses Claude if a key is set, else offline."""
    if settings.anthropic_api_key():
        try:
            return _tailor_with_claude(job_description, company, role)
        except Exception as exc:  # network/auth/etc. — degrade gracefully
            print(f"[tailor] Claude path failed ({exc}); falling back to offline.")
    return _tailor_offline(job_description, company, role)


def _slug(*parts: str) -> str:
    raw = "-".join(p for p in parts if p)
    return re.sub(r"[^a-z0-9]+", "-", raw.lower()).strip("-")[:60] or "job"


def build_application_package(
    job_description: str,
    company: str,
    role: str,
    out_dir: Path | None = None,
) -> Path:
    """Generate a tailored CV PDF + cover letter into output/applications/<slug>/.

    This only assembles documents; submission remains a separate, human-approved step.
    """
    from . import cv_generator

    content = tailor_for_job(job_description, company, role)

    if out_dir is None:
        base = settings.resolve_path(settings.load_config()["paths"]["output_dir"]) / "applications"
        out_dir = base / _slug(company, role)
    out_dir = Path(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    overrides = {"profile_text": content.profile_summary, "competencies": content.competencies}

    # Cover letter (markdown/plain text)
    (out_dir / "cover_letter.md").write_text(content.cover_letter + "\n", encoding="utf-8")

    # Match notes for review
    notes = (
        f"# Application package — {role} @ {company}\n\n"
        f"Generated by: {content.source}\n\n"
        f"## Match highlights\n" + "\n".join(f"- {h}" for h in content.match_highlights) + "\n"
    )
    (out_dir / "notes.md").write_text(notes, encoding="utf-8")

    # Tailored CV
    try:
        cv_path = cv_generator.generate_cv(output_path=out_dir / "CV.pdf", overrides=overrides)
    except RuntimeError as e:
        cv_path = cv_generator.write_html_preview(output_path=out_dir / "CV.html", overrides=overrides)
        print(f"[tailor] PDF unavailable ({e}); wrote HTML CV instead: {cv_path}")

    print(f"[tailor] Package ready: {out_dir}")
    return out_dir


if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(description="Tailor CV + cover letter for a job.")
    parser.add_argument("--jd", required=True, help="Path to a job-description text file")
    parser.add_argument("--company", required=True)
    parser.add_argument("--role", required=True)
    args = parser.parse_args()

    jd_text = Path(args.jd).read_text(encoding="utf-8")
    build_application_package(jd_text, args.company, args.role)
