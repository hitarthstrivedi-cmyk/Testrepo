"""Profile ingest: load the master profile and extract text from CV files.

The master profile (inputs/master_profile.yaml) is the single source of truth used
by the CV generator and the tailoring engine. Raw CV files (PDF/DOCX) can also be
read to text — useful as extra context for tailoring or for re-bootstrapping the
profile.
"""

from __future__ import annotations

from pathlib import Path
from typing import Any

import yaml

from .settings import PROJECT_ROOT, load_config, resolve_path

MASTER_PROFILE_FILENAME = "master_profile.yaml"


def master_profile_path() -> Path:
    cfg = load_config()
    inputs_dir = resolve_path(cfg.get("paths", {}).get("inputs_dir", "inputs"))
    return inputs_dir / MASTER_PROFILE_FILENAME


def load_master_profile(path: Path | None = None) -> dict[str, Any]:
    """Load and lightly validate the master profile."""
    target = path or master_profile_path()
    if not target.exists():
        raise FileNotFoundError(
            f"Master profile not found: {target}\n"
            "Create inputs/master_profile.yaml (see the auto-drafted template)."
        )
    with target.open("r", encoding="utf-8") as fh:
        data = yaml.safe_load(fh) or {}

    missing = [k for k in ("name", "headline", "profile", "experience") if not data.get(k)]
    if missing:
        raise ValueError(f"Master profile is missing required fields: {', '.join(missing)}")
    return data


# --- Raw CV text extraction ---------------------------------------------------

def extract_text(path: str | Path) -> str:
    """Extract plain text from a .pdf or .docx CV file."""
    p = Path(path)
    if not p.exists():
        raise FileNotFoundError(p)
    suffix = p.suffix.lower()
    if suffix == ".pdf":
        return _extract_pdf(p)
    if suffix in (".docx", ".doc"):
        return _extract_docx(p)
    if suffix in (".txt", ".md"):
        return p.read_text(encoding="utf-8", errors="ignore")
    raise ValueError(f"Unsupported CV format: {suffix} (use .pdf, .docx, .txt)")


def _extract_pdf(p: Path) -> str:
    from pypdf import PdfReader

    reader = PdfReader(str(p))
    return "\n".join((page.extract_text() or "") for page in reader.pages).strip()


def _extract_docx(p: Path) -> str:
    import docx  # python-docx

    document = docx.Document(str(p))
    return "\n".join(para.text for para in document.paragraphs).strip()


# --- Flattened profile text (LLM context) -------------------------------------

def profile_as_text(profile: dict[str, Any] | None = None) -> str:
    """Render the master profile as compact plain text for use as model context."""
    p = profile or load_master_profile()
    lines: list[str] = [f"{p['name']} — {p['headline']}", "", "PROFILE:", p["profile"].strip(), ""]

    if p.get("core_competencies"):
        lines += ["CORE COMPETENCIES: " + ", ".join(p["core_competencies"]), ""]
    if p.get("tools"):
        lines += ["TOOLS: " + ", ".join(p["tools"]), ""]

    lines.append("EXPERIENCE:")
    for job in p.get("experience", []):
        lines.append(
            f"- {job['role']}, {job['company']} ({job.get('location','')}) "
            f"{job.get('start','')}–{job.get('end','')}"
        )
        for h in job.get("highlights", []):
            lines.append(f"    • {h}")
    lines.append("")

    if p.get("education"):
        lines.append("EDUCATION:")
        for ed in p["education"]:
            lines.append(f"- {ed['degree']}, {ed['institution']} ({ed.get('end','')})")
        lines.append("")

    if p.get("achievements"):
        lines += ["ACHIEVEMENTS:"] + [f"- {a}" for a in p["achievements"]] + [""]

    return "\n".join(lines).strip()


if __name__ == "__main__":
    prof = load_master_profile()
    print(f"Loaded master profile for: {prof['name']}")
    print(f"  Roles: {len(prof.get('experience', []))}")
    print(f"  Competencies: {len(prof.get('core_competencies', []))}")
