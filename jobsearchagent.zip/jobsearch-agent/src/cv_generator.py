"""Generate the EU/Dutch-standard CV from the master profile.

Pipeline: master_profile.yaml -> Jinja2 (templates/cv_nl.html + cv.css) -> HTML -> PDF.

The CV is reverse-chronological, single column, short personal profile, and OMITS
photo / age / marital status / gender / nationality (Dutch anti-discrimination norm).
Re-theme by editing templates/cv.css.

`generate_cv()` accepts optional `overrides` so the Phase 1 tailoring engine can
swap in a job-specific profile summary and re-ordered competencies without touching
the master profile.
"""

from __future__ import annotations

from datetime import datetime
from pathlib import Path
from typing import Any

from jinja2 import Environment, FileSystemLoader, select_autoescape

from .profile import load_master_profile
from .settings import load_config, resolve_path

_MONTHS = {
    "01": "Jan", "02": "Feb", "03": "Mar", "04": "Apr", "05": "May", "06": "Jun",
    "07": "Jul", "08": "Aug", "09": "Sep", "10": "Oct", "11": "Nov", "12": "Dec",
}


def _templates_dir() -> Path:
    cfg = load_config()
    return resolve_path(cfg.get("paths", {}).get("templates_dir", "templates"))


def fmt_dates(start: str | None, end: str | None) -> str:
    """'2024-02' + 'present' -> 'Feb 2024 – Present'."""
    return f"{_fmt_one(start)} – {_fmt_one(end)}".strip(" –")


def _fmt_one(value: str | None) -> str:
    if not value:
        return ""
    if str(value).lower() == "present":
        return "Present"
    s = str(value)
    if "-" in s:
        year, _, month = s.partition("-")
        if month in _MONTHS:
            return f"{_MONTHS[month]} {year}"
        return year
    return s


def fmt_year(value: str | None) -> str:
    if not value:
        return ""
    return str(value).split("-")[0]


def _env() -> Environment:
    env = Environment(
        loader=FileSystemLoader(str(_templates_dir())),
        autoescape=select_autoescape(["html", "xml"]),
        trim_blocks=True,
        lstrip_blocks=True,
    )
    env.globals.update(fmt_dates=fmt_dates, fmt_year=fmt_year)
    return env


def render_html(profile: dict[str, Any] | None = None, overrides: dict[str, Any] | None = None) -> str:
    """Render the CV to an HTML string. `overrides` may set 'profile_text' and 'competencies'."""
    p = profile or load_master_profile()
    overrides = overrides or {}
    css = (_templates_dir() / "cv.css").read_text(encoding="utf-8")

    context = {
        "p": p,
        "css": css,
        "headline": overrides.get("headline", p.get("headline", "")),
        "profile_text": overrides.get("profile_text", p.get("profile", "")).strip(),
        "competencies": overrides.get("competencies", p.get("core_competencies", [])),
    }
    return _env().get_template("cv_nl.html").render(**context)


def generate_cv(
    output_path: str | Path | None = None,
    profile: dict[str, Any] | None = None,
    overrides: dict[str, Any] | None = None,
) -> Path:
    """Render and write the CV PDF. Returns the output path.

    Requires WeasyPrint's native libraries (see README). Raises a clear error if missing.
    """
    p = profile or load_master_profile()
    html = render_html(p, overrides)

    if output_path is None:
        cfg = load_config()
        out_dir = resolve_path(cfg.get("paths", {}).get("output_dir", "output")) / "cv"
        out_dir.mkdir(parents=True, exist_ok=True)
        safe_name = p["name"].replace(" ", "_")
        output_path = out_dir / f"{safe_name}_CV.pdf"

    output_path = Path(output_path)
    output_path.parent.mkdir(parents=True, exist_ok=True)

    try:
        from weasyprint import HTML
    except OSError as exc:  # native libs missing
        raise RuntimeError(
            "WeasyPrint native libraries are missing. Install them (see README) "
            "e.g. `apt-get install libpango-1.0-0 libpangocairo-1.0-0 libgdk-pixbuf2.0-0`."
        ) from exc

    HTML(string=html, base_url=str(_templates_dir())).write_pdf(str(output_path))
    return output_path


def write_html_preview(output_path: str | Path | None = None, **kwargs: Any) -> Path:
    """Write the rendered HTML (no PDF). Useful to preview/verify without native libs."""
    html = render_html(**kwargs)
    if output_path is None:
        cfg = load_config()
        out_dir = resolve_path(cfg.get("paths", {}).get("output_dir", "output")) / "cv"
        out_dir.mkdir(parents=True, exist_ok=True)
        output_path = out_dir / "cv_preview.html"
    output_path = Path(output_path)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text(html, encoding="utf-8")
    return output_path


if __name__ == "__main__":
    import sys

    if "--html" in sys.argv:
        out = write_html_preview()
        print(f"HTML preview written: {out}")
    else:
        try:
            out = generate_cv()
            print(f"CV PDF written: {out}")
        except RuntimeError as e:
            print(f"PDF generation unavailable ({e}). Writing HTML preview instead.")
            print(f"HTML preview: {write_html_preview()}")
            print(f"Datetime: {datetime.now().isoformat(timespec='seconds')}")
