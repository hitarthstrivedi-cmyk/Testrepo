"""Phase 4 — Human-in-the-loop (HITL) application workflow.

Hard guarantees:
  * NOTHING is ever submitted automatically. There is no auto-submit code path.
  * An application is only SENT after you explicitly approve it (`approved = 1`).
  * Email addresses are NEVER invented — only addresses actually listed on the job page
    are used. If none is found, the email path is unavailable and we fall back to a
    manual handoff.
  * Online forms are never auto-filled-and-submitted through platforms. We prepare a
    pre-fill sheet and a one-click link for YOU to submit.

Typical flow:
  1. approve_to_pursue(job_id)   -> generates the tailored package + detects the method
  2. (you review the package)
  3. approve_send(application_id) -> sets the explicit send gate (approved = 1)
  4. send_application(application_id):
       - email method: sends the drafted email (only if approved) and marks Applied
       - form method : prints the handoff; YOU submit, then mark_status(..., "Applied")
"""

from __future__ import annotations

import argparse
import datetime as _dt
import re
import smtplib
from email.message import EmailMessage
from pathlib import Path

from . import settings
from .compliance import ComplianceGate
from .db import connect, init_db
from .profile import load_master_profile
from .sources.base import polite_get

_EMAIL_RE = re.compile(r"[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}")
_APPLY_HINTS = ("apply", "sollicit", "vacature", "application", "apply-now")


def _now() -> str:
    return _dt.datetime.utcnow().isoformat(timespec="seconds")


def _get_job(conn, job_id: int) -> dict:
    row = conn.execute("SELECT * FROM jobs WHERE id = ?", (job_id,)).fetchone()
    if not row:
        raise ValueError(f"No job with id {job_id}")
    return dict(row)


def _add_history(conn, application_id: int, from_status: str | None, to_status: str, note: str = "") -> None:
    conn.execute(
        "INSERT INTO status_history (application_id, from_status, to_status, note, changed_at) "
        "VALUES (?, ?, ?, ?, ?)",
        (application_id, from_status, to_status, note, _now()),
    )


# --- Application-method detection --------------------------------------------

def detect_method(url: str) -> dict:
    """Inspect the job page to decide email vs form. Never invents an address.

    Returns {method, hr_email, apply_url, candidates, note}.
    """
    gate = ComplianceGate()
    result = {"method": "unknown", "hr_email": None, "apply_url": url, "candidates": [], "note": ""}

    try:
        html, decision = polite_get(gate, url)
    except Exception as exc:
        result["note"] = f"Could not fetch page: {exc}"
        return result

    if html is None:
        result["note"] = (f"Notify-only/blocked source ({decision.reason}); open and apply manually."
                          if decision.notify_only else f"Not fetched: {decision.reason}")
        return result

    from bs4 import BeautifulSoup  # lazy
    soup = BeautifulSoup(html, "lxml")

    # 1) mailto links are the strongest "listed HR address" signal.
    mailtos = []
    for a in soup.select('a[href^="mailto:"]'):
        addr = a.get("href", "")[len("mailto:"):].split("?")[0].strip()
        if _EMAIL_RE.fullmatch(addr):
            mailtos.append(addr)

    # 2) Plain email addresses written on the page (also "listed", not invented).
    text_emails = [e for e in _EMAIL_RE.findall(soup.get_text(" ")) if not e.lower().endswith((".png", ".jpg"))]

    candidates = list(dict.fromkeys(mailtos + text_emails))  # de-dup, mailtos first
    result["candidates"] = candidates

    if candidates:
        result["method"] = "email"
        result["hr_email"] = candidates[0]
        result["note"] = "Email address found on the page (listed, not invented). Review before sending."
        return result

    # 3) Otherwise look for an apply form / apply link.
    if soup.find("form") or any(
        h in (a.get("href", "") + " " + a.get_text(" ")).lower()
        for a in soup.find_all("a") for h in _APPLY_HINTS
    ):
        result["method"] = "form"
        result["note"] = "Online application form detected; prepared a pre-fill sheet + handoff link."
        return result

    result["note"] = "Could not determine an apply method; treat as manual."
    return result


# --- Step 1: approve to pursue (generate package + detect method) ------------

def approve_to_pursue(job_id: int) -> int:
    """Create an application: generate the tailored package and detect the method.

    This does NOT send anything. Returns the application id.
    """
    from . import tailor

    init_db()
    with connect() as conn:
        job = _get_job(conn, job_id)

        existing = conn.execute("SELECT id FROM applications WHERE job_id = ?", (job_id,)).fetchone()
        if existing:
            print(f"[application] Application already exists for job {job_id} (id {existing['id']}).")
            return existing["id"]

        jd = job.get("description") or job.get("title")
        package_dir = tailor.build_application_package(jd, job["company_name"], job["title"])

        method_info = detect_method(job["url"])

        cur = conn.execute(
            """INSERT INTO applications (job_id, method, status, package_path, hr_email,
                   approved, notes, created_at, updated_at)
               VALUES (?, ?, 'Approved', ?, ?, 0, ?, ?, ?)""",
            (job_id, method_info["method"], str(package_dir), method_info["hr_email"],
             method_info["note"], _now(), _now()),
        )
        app_id = cur.lastrowid
        conn.execute("UPDATE jobs SET status = 'Approved' WHERE id = ?", (job_id,))
        _add_history(conn, app_id, "Found", "Approved", f"method={method_info['method']}")

        # Write a method-specific handoff/draft into the package for review.
        _write_handoff(Path(package_dir), job, method_info)

    print(f"[application] Prepared application {app_id} for job {job_id} "
          f"(method={method_info['method']}). NOT sent — review the package, then approve_send.")
    return app_id


def _write_handoff(package_dir: Path, job: dict, method_info: dict) -> None:
    profile = load_master_profile()
    contact = profile.get("contact", {})
    cover = (package_dir / "cover_letter.md")
    cover_text = cover.read_text(encoding="utf-8") if cover.exists() else ""

    if method_info["method"] == "email":
        draft = (
            f"To: {method_info['hr_email']}\n"
            f"Subject: Application — {job['title']}\n\n"
            f"{cover_text}\n\n"
            f"[Attachment to include when sending: {package_dir / 'CV.pdf'}]\n"
        )
        (package_dir / "email_draft.txt").write_text(draft, encoding="utf-8")
    else:
        prefill = (
            f"# Application handoff — {job['title']} @ {job['company_name']}\n\n"
            f"Open and submit yourself (no auto-submit):\n{method_info['apply_url']}\n\n"
            f"## Pre-fill (copy as needed)\n"
            f"- Name: {profile.get('name','')}\n"
            f"- Email: {contact.get('email','')}\n"
            f"- Phone: {contact.get('phone','')}\n"
            f"- Location: {contact.get('location','')}\n"
            f"- LinkedIn: {contact.get('linkedin','')}\n"
            f"- CV: {package_dir / 'CV.pdf'}\n"
            f"- Cover letter: {package_dir / 'cover_letter.md'}\n\n"
            f"Note: {method_info['note']}\n"
        )
        (package_dir / "handoff.md").write_text(prefill, encoding="utf-8")


# --- Step 2: explicit send gate ----------------------------------------------

def approve_send(application_id: int) -> None:
    """Set the explicit approval gate. Required before any email is sent."""
    with connect() as conn:
        row = conn.execute("SELECT status FROM applications WHERE id = ?", (application_id,)).fetchone()
        if not row:
            raise ValueError(f"No application {application_id}")
        conn.execute("UPDATE applications SET approved = 1, approved_at = ?, updated_at = ? WHERE id = ?",
                     (_now(), _now(), application_id))
        _add_history(conn, application_id, row["status"], row["status"], "send approved by user")
    print(f"[application] Application {application_id} approved for sending.")


# --- Step 3: send (email) / handoff (form) -----------------------------------

def send_application(application_id: int) -> None:
    """Send the email application (only if approved) or surface the form handoff.

    Refuses to send anything unless `approved = 1`. There is no path that submits an
    online form automatically.
    """
    with connect() as conn:
        row = conn.execute("SELECT * FROM applications WHERE id = ?", (application_id,)).fetchone()
        if not row:
            raise ValueError(f"No application {application_id}")
        app = dict(row)

    if app["method"] == "form" or app["method"] == "unknown":
        handoff = Path(app["package_path"]) / "handoff.md"
        print(f"[application] {app['method']} method — no auto-submit. Open and submit yourself:")
        if handoff.exists():
            print(handoff.read_text(encoding="utf-8"))
        print("After you submit, run: --status {id} Applied".format(id=application_id))
        return

    # Email method — strict gate.
    if not app["approved"]:
        print(f"[application] BLOCKED: application {application_id} is not approved for sending. "
              f"Run approve_send first. Nothing was sent.")
        return
    if not app["hr_email"]:
        print("[application] No listed HR email; cannot send (addresses are never invented). "
              "Use the handoff instead.")
        return

    _send_email(app)
    with connect() as conn:
        conn.execute("UPDATE applications SET status='Applied', applied_at=?, updated_at=? WHERE id=?",
                     (_now(), _now(), application_id))
        conn.execute("UPDATE jobs SET status='Applied' WHERE id=?", (app["job_id"],))
        _add_history(conn, application_id, "Approved", "Applied", f"emailed {app['hr_email']}")
    print(f"[application] Sent to {app['hr_email']} and marked Applied.")


def _send_email(app: dict) -> None:
    cfg = settings.smtp_config()
    if not (cfg["host"] and cfg["user"] and cfg["password"] and cfg["from_addr"]):
        raise RuntimeError("SMTP not configured in .env (SMTP_HOST/USER/PASSWORD/FROM).")

    package = Path(app["package_path"])
    with connect() as conn:
        job = _get_job(conn, app["job_id"])

    body = (package / "cover_letter.md").read_text(encoding="utf-8") if (package / "cover_letter.md").exists() else ""
    msg = EmailMessage()
    msg["Subject"] = f"Application — {job['title']}"
    msg["From"] = cfg["from_addr"]
    msg["To"] = app["hr_email"]
    msg.set_content(body)

    cv = package / "CV.pdf"
    if cv.exists():
        msg.add_attachment(cv.read_bytes(), maintype="application", subtype="pdf", filename="CV.pdf")

    with smtplib.SMTP(cfg["host"], int(cfg["port"])) as server:
        server.starttls()
        server.login(cfg["user"], cfg["password"])
        server.send_message(msg)


# --- Status updates -----------------------------------------------------------

def mark_status(application_id: int, new_status: str, note: str = "") -> None:
    from .db import PIPELINE_STATES
    if new_status not in PIPELINE_STATES:
        raise ValueError(f"Status must be one of {PIPELINE_STATES}")
    with connect() as conn:
        row = conn.execute("SELECT status, job_id FROM applications WHERE id = ?", (application_id,)).fetchone()
        if not row:
            raise ValueError(f"No application {application_id}")
        conn.execute("UPDATE applications SET status=?, updated_at=? WHERE id=?",
                     (new_status, _now(), application_id))
        conn.execute("UPDATE jobs SET status=? WHERE id=?", (new_status, row["job_id"]))
        _add_history(conn, application_id, row["status"], new_status, note)
    print(f"[application] Application {application_id} -> {new_status}")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="HITL application workflow (never auto-submits).")
    g = parser.add_mutually_exclusive_group(required=True)
    g.add_argument("--approve", type=int, metavar="JOB_ID", help="Approve a job to pursue: build package + detect method.")
    g.add_argument("--approve-send", type=int, metavar="APP_ID", help="Set the explicit send gate.")
    g.add_argument("--send", type=int, metavar="APP_ID", help="Send email (if approved) or show form handoff.")
    g.add_argument("--status", nargs=2, metavar=("APP_ID", "STATUS"), help="Update application status.")
    args = parser.parse_args()

    if args.approve is not None:
        approve_to_pursue(args.approve)
    elif args.approve_send is not None:
        approve_send(args.approve_send)
    elif args.send is not None:
        send_application(args.send)
    elif args.status is not None:
        mark_status(int(args.status[0]), args.status[1])
