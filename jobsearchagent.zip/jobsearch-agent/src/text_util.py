"""Small text helpers shared across sourcing (company-name normalization, hashing)."""

from __future__ import annotations

import hashlib
import re

# Common Dutch/EU legal-entity suffixes to strip when matching company names.
_LEGAL_SUFFIXES = [
    "b.v.", "bv", "n.v.", "nv", "c.v.", "cv", "v.o.f.", "vof", "holding",
    "group", "groep", "international", "nederland", "netherlands", "the",
    "gmbh", "ltd", "limited", "inc", "llc", "s.a.", "sa", "se",
]

_PUNCT_RE = re.compile(r"[^\w\s&-]", re.UNICODE)
_WS_RE = re.compile(r"\s+")


def normalize_company(name: str) -> str:
    """Lowercase, strip punctuation and common legal suffixes for matching/dedup."""
    if not name:
        return ""
    s = name.lower().strip()
    # Collapse dotted abbreviations first so "b.v." -> "bv" (then stripped as a suffix),
    # rather than splitting into stray "b"/"v" tokens.
    s = s.replace(".", "")
    s = _PUNCT_RE.sub(" ", s)
    s = _WS_RE.sub(" ", s).strip()
    tokens = [t for t in s.split(" ") if t and t not in _LEGAL_SUFFIXES]
    return " ".join(tokens).strip()


def content_hash(company: str, title: str) -> str:
    """Stable hash identifying a role at a company (for repost detection)."""
    key = f"{normalize_company(company)}|{normalize_title(title)}"
    return hashlib.sha256(key.encode("utf-8")).hexdigest()[:16]


def normalize_title(title: str) -> str:
    s = (title or "").lower().strip()
    s = _PUNCT_RE.sub(" ", s)
    return _WS_RE.sub(" ", s).strip()
