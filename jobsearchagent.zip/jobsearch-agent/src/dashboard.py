"""Phase 5 — local tracking dashboard (Streamlit).

Shows every job found with its match score, recognised-sponsor and HSM-salary flags, the
application pipeline (Found → Approved → Applied → Response → Interview → Offer/Rejected),
notifications, and follow-up reminders. You can approve jobs, update statuses, and add
notes inline.

Run it (from the jobsearch-agent/ directory):

    streamlit run src/dashboard.py

Everything is local; it reads/writes the same SQLite DB the rest of the pipeline uses.
"""

from __future__ import annotations

import datetime as _dt
import sys
from pathlib import Path

# Allow `streamlit run src/dashboard.py` (script mode) to resolve the `src` package.
_PROJECT_ROOT = Path(__file__).resolve().parent.parent
if str(_PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(_PROJECT_ROOT))

from src import settings  # noqa: E402
from src.db import PIPELINE_STATES, connect, init_db  # noqa: E402

FOLLOWUP_STATES = ("Applied", "Response", "Interview")
DEFAULT_STALE_DAYS = 7


# =============================================================================
# Data access (no Streamlit dependency — unit-testable)
# =============================================================================

def summary_metrics() -> dict:
    with connect() as conn:
        row = conn.execute(
            """SELECT
                 COUNT(*) AS total,
                 COALESCE(SUM(is_recognised_sponsor), 0) AS sponsors,
                 COALESCE(SUM(notify_only), 0) AS notify_only
               FROM jobs"""
        ).fetchone()
        meets = conn.execute(
            "SELECT COUNT(*) c FROM match_scores WHERE salary_meets_threshold = 1"
        ).fetchone()["c"]
        scored = conn.execute("SELECT COUNT(*) c FROM match_scores").fetchone()["c"]
    return {"total": row["total"], "sponsors": row["sponsors"],
            "notify_only": row["notify_only"], "meets_threshold": meets, "scored": scored}


def pipeline_counts() -> dict:
    counts = {s: 0 for s in PIPELINE_STATES}
    with connect() as conn:
        for r in conn.execute("SELECT status, COUNT(*) c FROM jobs WHERE notify_only = 0 GROUP BY status"):
            counts[r["status"]] = counts.get(r["status"], 0) + r["c"]
    return counts


def load_jobs(status: str | None = None, sponsor_only: bool = False,
              meets_only: bool = False, min_score: int = 0) -> list[dict]:
    sql = [
        """SELECT j.id, j.title, j.company_name, j.location, j.url, j.source, j.status,
                  j.is_recognised_sponsor, j.salary_text, j.salary_min, j.salary_max,
                  j.is_repost, j.first_seen, j.last_seen,
                  m.score, m.rationale, m.strengths, m.gaps, m.salary_meets_threshold,
                  a.id AS app_id, a.method AS app_method, a.approved AS app_approved,
                  a.notes AS app_notes
           FROM jobs j
           LEFT JOIN match_scores m ON m.job_id = j.id
           LEFT JOIN applications a ON a.job_id = j.id
           WHERE j.notify_only = 0"""
    ]
    params: list = []
    if status and status != "All":
        sql.append("AND j.status = ?"); params.append(status)
    if sponsor_only:
        sql.append("AND j.is_recognised_sponsor = 1")
    if meets_only:
        sql.append("AND m.salary_meets_threshold = 1")
    if min_score:
        sql.append("AND COALESCE(m.score, 0) >= ?"); params.append(min_score)
    sql.append("ORDER BY m.score DESC, j.last_seen DESC")

    with connect() as conn:
        return [dict(r) for r in conn.execute(" ".join(sql), params).fetchall()]


def load_notifications(unread_only: bool = False, limit: int = 100) -> list[dict]:
    q = "SELECT id, type, title, body, is_read, created_at FROM notifications"
    if unread_only:
        q += " WHERE is_read = 0"
    q += " ORDER BY created_at DESC LIMIT ?"
    with connect() as conn:
        return [dict(r) for r in conn.execute(q, (limit,)).fetchall()]


def mark_notification_read(notif_id: int) -> None:
    with connect() as conn:
        conn.execute("UPDATE notifications SET is_read = 1 WHERE id = ?", (notif_id,))


def _days_since(ts: str | None) -> int | None:
    if not ts:
        return None
    try:
        dt = _dt.datetime.fromisoformat(ts)
    except ValueError:
        return None
    return (_dt.datetime.utcnow() - dt).days


def followups(stale_days: int = DEFAULT_STALE_DAYS) -> list[dict]:
    """Applications in an active state whose last update is older than stale_days."""
    placeholders = ",".join("?" for _ in FOLLOWUP_STATES)
    out: list[dict] = []
    with connect() as conn:
        rows = conn.execute(
            f"""SELECT a.id app_id, a.status, a.updated_at, j.title, j.company_name
                FROM applications a JOIN jobs j ON j.id = a.job_id
                WHERE a.status IN ({placeholders})""",
            FOLLOWUP_STATES,
        ).fetchall()
    for r in rows:
        days = _days_since(r["updated_at"])
        if days is not None and days >= stale_days:
            d = dict(r); d["days_since_update"] = days
            out.append(d)
    return sorted(out, key=lambda x: -x["days_since_update"])


def save_notes(app_id: int, notes: str) -> None:
    with connect() as conn:
        conn.execute("UPDATE applications SET notes = ?, updated_at = ? WHERE id = ?",
                     (notes, _dt.datetime.utcnow().isoformat(timespec="seconds"), app_id))


# =============================================================================
# Streamlit UI
# =============================================================================

def _fmt_flag(value, yes="✅", no="❌", unknown="—") -> str:
    if value is None:
        return unknown
    return yes if value else no


def render() -> None:
    import streamlit as st

    from src import application

    init_db()
    st.set_page_config(page_title="NL HSM Job-Search", layout="wide")
    st.title("🇳🇱 Highly Skilled Migrant Job-Search")
    st.caption("Local, single-user. Match scores are a relevance heuristic — NOT a "
               "probability of being shortlisted. Nothing is submitted without your approval.")

    # --- Sidebar: filters + run controls ---
    with st.sidebar:
        st.header("Filters")
        status = st.selectbox("Status", ["All"] + PIPELINE_STATES)
        sponsor_only = st.checkbox("Recognised sponsors only")
        meets_only = st.checkbox("Meets HSM salary only")
        min_score = st.slider("Min match score", 0, 100, 0, 5)
        st.divider()
        st.header("Run")
        if st.button("Run sourcing"):
            from src import sourcing
            with st.spinner("Sourcing…"):
                st.session_state["last_run"] = sourcing.run_sourcing()
        if st.button("Score new jobs"):
            from src import matching
            with st.spinner("Scoring…"):
                st.session_state["last_score"] = matching.score_all()
        if st.session_state.get("last_run"):
            st.caption(f"Sourcing: {st.session_state['last_run']}")
        if st.session_state.get("last_score"):
            st.caption(f"Scoring: {st.session_state['last_score']}")

    # --- Metrics ---
    m = summary_metrics()
    c1, c2, c3, c4, c5 = st.columns(5)
    c1.metric("Jobs", m["total"])
    c2.metric("Recognised sponsors", m["sponsors"])
    c3.metric("Meet HSM salary", m["meets_threshold"])
    c4.metric("Scored", m["scored"])
    c5.metric("Notify-only", m["notify_only"])

    tab_jobs, tab_pipeline, tab_notifs, tab_followups = st.tabs(
        ["Jobs", "Pipeline", "Notifications", "Follow-ups"])

    # --- Jobs ---
    with tab_jobs:
        jobs = load_jobs(status, sponsor_only, meets_only, min_score)
        st.write(f"{len(jobs)} job(s)")
        for j in jobs:
            score = j["score"] if j["score"] is not None else "—"
            sponsor = "🏅 sponsor" if j["is_recognised_sponsor"] else ""
            repost = "🔁 repost" if j["is_repost"] else ""
            header = f"[{score}] {j['title']} — {j['company_name']}  {sponsor} {repost}".strip()
            with st.expander(header):
                st.markdown(f"**Location:** {j['location'] or '—'}  ·  "
                            f"**Source:** {j['source']}  ·  [Open posting]({j['url']})")
                st.markdown(f"**HSM salary met:** {_fmt_flag(j['salary_meets_threshold'])}  ·  "
                            f"**Listed:** {j['salary_text'] or '—'}  ·  "
                            f"**Status:** {j['status']}")
                if j["rationale"]:
                    st.markdown(f"_{j['rationale']}_")
                    if j["strengths"]:
                        st.markdown(f"**Strengths:** {j['strengths']}")
                    if j["gaps"]:
                        st.markdown(f"**Gaps:** {j['gaps']}")

                cols = st.columns([1, 1, 2])
                # Approve to pursue (creates an application + package)
                if j["app_id"] is None:
                    if cols[0].button("Approve to pursue", key=f"approve_{j['id']}"):
                        application.approve_to_pursue(j["id"])
                        st.rerun()
                else:
                    cols[0].caption(f"App #{j['app_id']} · {j['app_method']} · "
                                    f"{'approved to send' if j['app_approved'] else 'not approved'}")

                # Status update
                new_status = cols[1].selectbox("Set status", PIPELINE_STATES,
                                               index=PIPELINE_STATES.index(j["status"])
                                               if j["status"] in PIPELINE_STATES else 0,
                                               key=f"status_{j['id']}")
                if cols[1].button("Update", key=f"upd_{j['id']}"):
                    if j["app_id"] is not None:
                        application.mark_status(j["app_id"], new_status)
                    else:
                        with connect() as conn:
                            conn.execute("UPDATE jobs SET status=? WHERE id=?", (new_status, j["id"]))
                    st.rerun()

                # Notes (only when an application exists)
                if j["app_id"] is not None:
                    notes = cols[2].text_area("Notes", value=j["app_notes"] or "", key=f"notes_{j['id']}")
                    if cols[2].button("Save notes", key=f"savenotes_{j['id']}"):
                        save_notes(j["app_id"], notes)
                        st.success("Saved.")

    # --- Pipeline ---
    with tab_pipeline:
        counts = pipeline_counts()
        cols = st.columns(len(PIPELINE_STATES))
        for col, state in zip(cols, PIPELINE_STATES):
            col.metric(state, counts.get(state, 0))

    # --- Notifications ---
    with tab_notifs:
        only_unread = st.checkbox("Unread only", value=True)
        notifs = load_notifications(unread_only=only_unread)
        st.write(f"{len(notifs)} notification(s)")
        for n in notifs:
            cols = st.columns([6, 1])
            badge = {"new": "🆕", "repost": "🔁", "info": "ℹ️"}.get(n["type"], "•")
            cols[0].markdown(f"{badge} **{n['title']}**  \n{n['body']}  \n`{n['created_at']}`")
            if not n["is_read"] and cols[1].button("Read", key=f"read_{n['id']}"):
                mark_notification_read(n["id"])
                st.rerun()

    # --- Follow-ups ---
    with tab_followups:
        stale = st.slider("Flag if no update in (days)", 1, 30, DEFAULT_STALE_DAYS)
        fups = followups(stale)
        if not fups:
            st.success("No follow-ups due.")
        for f in fups:
            st.warning(f"**{f['title']} — {f['company_name']}** · {f['status']} · "
                       f"{f['days_since_update']} days since update (app #{f['app_id']})")


if __name__ == "__main__":
    render()
