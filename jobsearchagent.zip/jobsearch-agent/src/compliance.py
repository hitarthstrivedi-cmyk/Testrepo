"""Compliance enforcement layer.

This module is the single gate every outbound web request in later phases must pass
through. It enforces three rules, in order:

  1. ToS denylist  — domains whose Terms of Service forbid scraping (LinkedIn, Indeed,
     ...) are NEVER fetched. They are "notify-only": store the link, tell the user to
     open it manually.
  2. robots.txt    — honoured per-domain (cached).
  3. Rate limiting — a minimum delay between requests to the same domain.

Phase 0 ships the enforcement logic and a self-test; the actual fetching wrappers are
used by the Phase 2 sourcing adapters. Keeping this here means no adapter can
accidentally bypass the rules.
"""

from __future__ import annotations

import threading
import time
import urllib.robotparser
from dataclasses import dataclass
from typing import Optional
from urllib.parse import urlparse

from .settings import load_config


def _registrable_domain(url: str) -> str:
    """Best-effort registrable domain from a URL host (e.g. jobs.linkedin.com -> linkedin.com)."""
    host = (urlparse(url).hostname or "").lower()
    if not host:
        return ""
    parts = host.split(".")
    return ".".join(parts[-2:]) if len(parts) >= 2 else host


@dataclass
class FetchDecision:
    """Outcome of a pre-fetch compliance check."""
    allowed: bool
    reason: str
    notify_only: bool = False  # True => store link & surface to user instead of fetching


class ComplianceGate:
    """Decides whether a URL may be fetched, and rate-limits those that may.

    Thread-safe enough for the project's single-process use.
    """

    def __init__(self, config: Optional[dict] = None):
        cfg = (config or load_config()).get("compliance", {})
        self.notify_only_domains = {d.lower() for d in cfg.get("notify_only_domains", [])}
        self.respect_robots = bool(cfg.get("respect_robots_txt", True))
        self.rate_limit_seconds = float(cfg.get("rate_limit_seconds_per_domain", 5))
        self.timeout = int(cfg.get("request_timeout_seconds", 20))
        self.user_agent = cfg.get("user_agent", "personal-jobsearch-agent/0.1")

        self._last_request_at: dict[str, float] = {}
        self._robots_cache: dict[str, urllib.robotparser.RobotFileParser] = {}
        self._lock = threading.Lock()

    # --- Rule 1: ToS denylist -------------------------------------------------
    def is_notify_only(self, url: str) -> bool:
        domain = _registrable_domain(url)
        return any(domain == d or domain.endswith("." + d) for d in self.notify_only_domains)

    # --- Rule 2: robots.txt ---------------------------------------------------
    def _robots_for(self, url: str) -> urllib.robotparser.RobotFileParser:
        parsed = urlparse(url)
        base = f"{parsed.scheme}://{parsed.netloc}"
        with self._lock:
            rp = self._robots_cache.get(base)
            if rp is None:
                rp = urllib.robotparser.RobotFileParser()
                rp.set_url(f"{base}/robots.txt")
                try:
                    rp.read()
                except Exception:
                    # If robots.txt can't be read, fail safe: disallow.
                    rp = None  # type: ignore[assignment]
                self._robots_cache[base] = rp  # may cache None to avoid re-fetching
            return rp

    def robots_allows(self, url: str) -> bool:
        if not self.respect_robots:
            return True
        rp = self._robots_for(url)
        if rp is None:
            return False  # could not read robots.txt -> fail safe
        return rp.can_fetch(self.user_agent, url)

    # --- Public decision ------------------------------------------------------
    def check(self, url: str) -> FetchDecision:
        """Decide whether `url` may be fetched. Does not perform any network call beyond robots.txt."""
        if not urlparse(url).scheme.startswith("http"):
            return FetchDecision(False, "not an http(s) url")
        if self.is_notify_only(url):
            return FetchDecision(
                False,
                f"'{_registrable_domain(url)}' is ToS notify-only; open manually",
                notify_only=True,
            )
        if not self.robots_allows(url):
            return FetchDecision(False, "disallowed by robots.txt")
        return FetchDecision(True, "ok")

    # --- Rule 3: rate limiting ------------------------------------------------
    def wait_for_rate_limit(self, url: str) -> None:
        """Block until enough time has passed since the last request to this domain."""
        domain = _registrable_domain(url)
        with self._lock:
            last = self._last_request_at.get(domain, 0.0)
            elapsed = time.monotonic() - last
            sleep_for = self.rate_limit_seconds - elapsed
        if sleep_for > 0:
            time.sleep(sleep_for)
        with self._lock:
            self._last_request_at[domain] = time.monotonic()


def self_test() -> None:
    """Quick sanity check that the denylist and decisions behave (no network for denylist cases)."""
    gate = ComplianceGate()
    checks = [
        ("https://www.linkedin.com/jobs/view/123", False, True),
        ("https://jobs.indeed.com/abc", False, True),
        ("ftp://example.com/file", False, False),
    ]
    for url, exp_allowed, exp_notify in checks:
        d = gate.check(url)
        flag = "OK" if (d.allowed == exp_allowed and d.notify_only == exp_notify) else "FAIL"
        print(f"[{flag}] {url} -> allowed={d.allowed} notify_only={d.notify_only} ({d.reason})")


if __name__ == "__main__":
    self_test()
