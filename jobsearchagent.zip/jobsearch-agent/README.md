# Job-Search Agent (Netherlands HSM / kennismigrant)

A **personal, single-user, fully-local** semi-autonomous job-search assistant. It helps you
find and pursue a Dutch *highly skilled migrant* (kennismigrant / HSM) role while based abroad.

> **Design principles (non-negotiable):**
> 1. **Compliance first** — never scrape sites whose Terms of Service forbid it (LinkedIn,
>    Indeed, etc. are *notify-only*). robots.txt is respected and requests are rate-limited.
> 2. **Human-in-the-loop (HITL)** — nothing is ever submitted or emailed automatically. Every
>    application requires your explicit approval. There is no auto-submit code path.
> 3. **Everything runs locally** — SQLite for storage, a local Streamlit dashboard, secrets in
>    `.env` only.

## Tech stack
| Concern            | Choice                                  |
|--------------------|-----------------------------------------|
| Storage            | SQLite                                  |
| Dashboard          | Streamlit                               |
| CV / cover letter  | HTML + CSS rendered to PDF via WeasyPrint |
| AI tailoring/score | Claude API (Anthropic)                  |
| Config             | `config/config.yaml`                    |
| Secrets            | `.env` (never committed)                |

## Build phases
- **Phase 0 — setup**: project scaffold, SQLite schema, config, compliance skeleton.
- **Phase 1 — documents**: ingest CV + master profile → generate EU/Dutch CV → per-job tailoring + NL cover letter.
- **Phase 2 — sourcing**: IND recognised-sponsors register + compliant job sources, dedup, new/repost detection, notifications, scheduling.
- **Phase 3 — matching**: 0–100 relevance score + rationale, HSM salary-threshold flag.
- **Phase 4 — HITL workflow**: assemble approved application packages; prepare (never auto-send) form/email submissions.
- **Phase 5 — dashboard**: local pipeline tracker (Found → Approved → Applied → Response → Interview → Offer/Rejected).

## Setup (Phase 0)

```bash
cd jobsearch-agent
python3 -m venv .venv
source .venv/bin/activate          # Windows: .venv\Scripts\activate
pip install -r requirements.txt

cp .env.example .env               # then edit .env and add your ANTHROPIC_API_KEY
python -m src.db                   # create the SQLite database + tables
```

`python -m src.db` is idempotent — safe to re-run; it creates `data/jobsearch.db` if missing.

### WeasyPrint note
WeasyPrint needs native libs (Pango, Cairo, GDK-PixBuf). On Debian/Ubuntu:
`sudo apt-get install libpango-1.0-0 libpangocairo-1.0-0 libgdk-pixbuf2.0-0 libffi-dev`.
On macOS: `brew install pango`. (Only needed once Phase 1 generates PDFs.)

## Configuration
Edit `config/config.yaml` — target roles/keywords, locations, minimum salary, seniority,
notification preferences, and the (pluggable) list of compliant job sources.

## Phase 1 — documents

Your editable source of truth is **`inputs/master_profile.yaml`** (auto-drafted from your
CV — review and enrich it, especially metrics). The CV generator and tailoring engine both
read from it.

```bash
# 1) Generate the EU/Dutch CV (PDF). Add --html for an HTML-only preview (no native libs).
python -m src.cv_generator

# 2) Tailor for a specific job: produces output/applications/<slug>/ with
#    a tailored CV.pdf, cover_letter.md, and notes.md.
python -m src.tailor --jd path/to/job_description.txt \
    --company "Company BV" --role "AI Transformation Lead"
```

- Tailoring uses the **Claude API** when `ANTHROPIC_API_KEY` is set (Opus 4.8, adaptive
  thinking, master profile prompt-cached). With no key it falls back to a deterministic
  **offline** mode (keyword-ranked competencies + templated cover letter).
- The CV omits photo / age / marital status / gender / nationality by design. Re-theme by
  editing `templates/cv.css`; change structure in `templates/cv_nl.html`.
- Nothing is ever submitted — Phase 1 only produces documents for your review.

## Phase 2 — sourcing

Find sponsored companies and current openings from **compliant sources only**.

### IND recognised-sponsors register
The register is published by IND as a downloadable file, refreshed monthly. Download it
from the [public register page](https://ind.nl/en/public-register-recognised-sponsors/public-register-regular-labour-and-highly-skilled-migrants),
then ingest it (PDF/CSV/TXT supported):

```bash
python -m src.ind_register --file ~/Downloads/Public_register_Regular_labour_and_HSM.pdf
# or attempt a direct download (if the configured URL points at the file):
python -m src.ind_register
```

This stores ~10k companies, flags a loose field-relevance shortlist, and snapshots each
download. Re-run monthly. The authoritative sponsor signal is applied automatically: any
job whose company matches the register is flagged `is_recognised_sponsor`.

### Job sources (pluggable)
Add sources under `sources.enabled` in `config.yaml` — built-in types are `career_page`
(HTML + CSS selectors) and `rss`. **ToS-forbidden domains (LinkedIn, Indeed, Glassdoor,
Monster) are hard-blocked** by the compliance layer and surfaced as *notify-only* links
you open manually. Every fetch respects robots.txt and a per-domain rate limit.

```bash
python -m src.sourcing            # run all enabled sources once
```

New and reposted matches (same role/company reappearing) are detected each run and written
to the notifications table (dashboard channel, always on); email is added when SMTP is set.

### Scheduling
**Local cron (recommended — keeps state on your machine):**
```bash
# Weekly, Mondays 08:00. `crontab -e` then add (use absolute paths):
0 8 * * 1 cd /path/to/jobsearch-agent && ./.venv/bin/python scripts/run_sourcing.py --register >> data/cron.log 2>&1
```

**GitHub Actions:** `.github/workflows/jobsearch-sourcing.yml` runs weekly and on demand.
It caches the SQLite DB between runs and reads optional `SMTP_*` repo secrets for email.
Note the state caveat in the workflow header — for fully reliable new/repost detection,
local cron is preferred.

## Phase 3 — matching + scoring

Score each stored job for **relevance to your master profile** and flag the salary:

```bash
python -m src.matching            # score jobs not yet scored
python -m src.matching --rescore  # re-score everything
```

- **Score (0–100)** is a **relevance heuristic** — how well the role aligns with your
  profile — **not a probability of being shortlisted**. Each score carries a short
  strengths/gaps rationale. Claude (Opus 4.8) when keyed; deterministic keyword-overlap
  fallback otherwise.
- **HSM salary flag** is computed deterministically from the listed salary, converted to a
  gross monthly figure and compared to the 2026 threshold (€5,942 for 30+). Foreign
  currencies and unlisted salaries are flagged *unknown* rather than guessed. Handles EU
  (`€5.942`, `€71.304 per jaar`) and US number formats.

## Phase 4 — HITL application workflow

**Nothing is ever submitted automatically. Every send requires your explicit approval.**

```bash
# 1) Approve a job to pursue: builds the tailored package + detects the apply method.
python -m src.application --approve <JOB_ID>

# 2) Review the package in output/applications/<slug>/
#    (CV.pdf, cover_letter.md, and either email_draft.txt or handoff.md)

# 3) Explicitly approve sending (the gate; required for email).
python -m src.application --approve-send <APP_ID>

# 4) Send / hand off.
python -m src.application --send <APP_ID>
#    - email method: sends the drafted email to the LISTED address (only if approved),
#      attaches the CV, and marks the job Applied.
#    - form/unknown: prints the pre-fill sheet + the apply URL for YOU to submit. No
#      auto-submit. After submitting, run: --status <APP_ID> Applied

# Update pipeline status / add a note at any time:
python -m src.application --status <APP_ID> Interview
```

Guarantees enforced in code: no auto-submit path exists; an email is refused unless
`approved = 1`; HR email addresses are only ever taken from the job page (never invented);
ToS-blocked pages fall back to a manual handoff.

## Phase 5 — tracking dashboard

A local Streamlit dashboard tying everything together:

```bash
streamlit run src/dashboard.py        # from the jobsearch-agent/ directory
```

- **Jobs** tab — every job with its match score, recognised-sponsor 🏅 and HSM-salary
  flags, rationale/strengths/gaps; inline **Approve to pursue**, **status updates**, and
  **notes**.
- **Pipeline** tab — counts across Found → Approved → Applied → Response → Interview →
  Offer/Rejected.
- **Notifications** tab — new/repost/info alerts; mark as read.
- **Follow-ups** tab — active applications with no update in N days.
- Sidebar — filters (status, sponsor-only, meets-HSM-salary, min score) and one-click
  **Run sourcing** / **Score new jobs**.

The header restates that the score is a relevance heuristic (not a shortlist probability)
and that nothing is submitted without your approval.

---

## End-to-end (all phases)

```bash
python -m src.db                                   # init DB (once)
python -m src.ind_register --file register.pdf     # Phase 2: load sponsors
python -m src.cv_generator                          # Phase 1: base CV
python -m src.sourcing                              # Phase 2: find jobs
python -m src.matching                              # Phase 3: score them
streamlit run src/dashboard.py                      # Phase 5: review + approve
# Phase 4 (per approved job): --approve / --approve-send / --send via src.application
```

## 2026 IND HSM salary thresholds (reference)
Gross **monthly**, **excluding** the 8% holiday allowance:
- **30 and older:** €5,942 / month
- **Under 30:** €4,357 / month

The **employer** (a recognised sponsor) runs the IND process — not the applicant. This tool
frames you as a *low-friction* hire: you clearly meet the threshold and HSM criteria, so
sponsorship is fast and low-risk for the employer.

## Repository layout
```
jobsearch-agent/
├── config/config.yaml          # your search + notification settings
├── data/                        # SQLite DB + dated IND register snapshots (git-ignored)
├── inputs/                       # your CV + master_profile.yaml
├── output/                       # generated CVs and per-job application packages (git-ignored)
├── templates/                    # re-themeable CV + cover-letter templates
├── src/
│   ├── db.py                     # SQLite schema + init
│   ├── settings.py               # load config.yaml + .env
│   └── compliance.py             # robots.txt, rate limiting, ToS denylist
└── scripts/                      # schedulable entrypoints (added in later phases)
```
