#!/usr/bin/env python3
"""Schedulable entrypoint: refresh the IND register monthly, then run sourcing.

Usage:
    python scripts/run_sourcing.py              # sourcing only
    python scripts/run_sourcing.py --register   # also refresh the IND register first
    python scripts/run_sourcing.py --register-file path/to/register.pdf

Schedule it with cron or GitHub Actions (see README → Scheduling).
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

# Allow running as a standalone script (python scripts/run_sourcing.py).
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from src import ind_register, sourcing  # noqa: E402
from src.db import init_db  # noqa: E402


def main() -> int:
    parser = argparse.ArgumentParser(description="Run the job-search sourcing pipeline.")
    parser.add_argument("--register", action="store_true",
                        help="Refresh the IND recognised-sponsor register before sourcing.")
    parser.add_argument("--register-file", help="Use a locally downloaded register file.")
    args = parser.parse_args()

    init_db()  # ensure schema exists

    if args.register or args.register_file:
        try:
            counts = ind_register.refresh(file=args.register_file)
            print(f"[register] {counts}")
        except Exception as exc:
            print(f"[register] refresh failed: {exc}")

    summary = sourcing.run_sourcing()
    print(f"[sourcing] {summary}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
